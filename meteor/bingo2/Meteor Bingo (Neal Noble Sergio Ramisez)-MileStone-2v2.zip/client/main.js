// Neal Noble
// Sergio Ramirez
// Meteor Team project: Bingo Time
// May 2016


import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';

import './main.html';

Template.bingoSquare.onCreated(function helloOnCreated()
{
    
});










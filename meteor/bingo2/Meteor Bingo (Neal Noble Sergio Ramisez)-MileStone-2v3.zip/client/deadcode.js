// mongoCardNumbers currently not used
//var mongoCardNumbers = randomCardNumbers.find();
// var item = mongoCardNumbers.hasNext();
// console.log(bingoSquareCounter);
// console.log("cardGridNumbers(): " + cardGridNumbers());
// console.log("cardGridNumbers().length: " + cardGridNumbers().length);



// export var getRandomNumberColumn_1 = (getRandomBingoNumber(16,31));
// export var getRandomNumberColumn_2 = (getRandomBingoNumber(16,31));
// export var getRandomNumberColumn_3 = (getRandomBingoNumber(31,46));
// export var getRandomNumberColumn_4 = (getRandomBingoNumber(46,61));
// export var getRandomNumberColumn_5 = (getRandomBingoNumber(61,76));

import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';
import { bookmarksCollion } from '../collections/collections.js';

import './main.html';

Template.bookmarks.helpers({
  bookmarksList: function() {
      // retreive all bookmarks from collections
      return bookmarksCollion.find()
  }
})



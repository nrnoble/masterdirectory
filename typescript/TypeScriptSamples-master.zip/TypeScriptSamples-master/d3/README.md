# TypeScript Sample: D3 

## Overview 

D3 visualization
- Use of the D3 wrapper 
- Use of modules and interfaces

## Running 
```
tsc --sourcemap data.ts
start perf.html
```
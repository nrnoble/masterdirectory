# TypeScript Sample: JQuery Parallax Starfield 

## Overview

This sample shows a simple jQuery application in TypeScript using a jQuery TypeScript typing.

## Usage

For best results, scroll the window using the scrollbar.  

## Running
```
tsc --sourcemap --target ES5 parallax.ts
start parallax.html
```

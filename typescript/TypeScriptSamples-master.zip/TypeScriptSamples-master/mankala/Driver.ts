///<reference path='Position.ts'/>
///<reference path='Geometry.ts'/>
///<reference path='Game.ts'/>
///<reference path='Features.ts'/>
///<reference path='Base.ts'/>

if (!this.document) {
    var game = new Mankala.Game();
    game.test();
}

# TypeScript Sample: Greeter 

## Overview 

This sample shows basic class definition and instantiation.

## Running
```
tsc --sourcemap greeter.ts
start greeter.html
```

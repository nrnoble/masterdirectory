# jsx-demo

## Overview
A demo project for showing off JSX in TypeScript

## Install dependencies
```
npm install
```

## Compile
```
node node_modules/typescript/bin/tsc
```

## Start http server
```
node node_modules/http-server/bin/http-server -o
```


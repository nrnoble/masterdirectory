<!--
Neal Noble
IT426
Assignment: MVC F.A.T Free in class example
Instructor Josh Archer
Dec 2016
-->

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>View {{ @username }} blogs</title>
</head>

<body>
<!-- shared header content goes here -->

<include href="{{ @content }}" />

<!-- shared footer content goes here -->
</body>
</html>

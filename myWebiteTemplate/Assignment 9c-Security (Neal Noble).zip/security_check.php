<?php
    require './includes/validate.php';
    require 'functions.php';


    if($_POST['verifyme'] != 'istrue')
    {

        die("Sorry no ice cream and cookies for you");
    }

    if(!strstr($_SERVER['HTTP_REFERER'], "nnoble.greenrivertech.net"))
    {
        die("Are you lost?");
    }

    $first_name  = htmlentities($_POST['first_name']);
    $last_name  = htmlentities($_POST['last_name']);
    $email = htmlentities($_POST['email']);
    $pwd1 = htmlentities($_POST['pwd1']);
    $pwd2 = htmlentities($_POST['pwd2']);

    $pwd1_hash  = sha1($pwd1);
    $pwd2_hash  = sha1($pwd2);

    if ($pwd1_hash  != $pwd2_hash)
    {

        header("Location: register.php");
        return;
        #die("Sorry your passwords do not match");
    }


    $servername = gethostname();
    $username = get_current_user();
    $password = getpwd();

    // Create connection
    $conn = new mysqli("127.0.0.1", $username, $password,"nnoble_grcc");

    // Check connection
    if ($conn->connect_error)
    {
        die("Connection failed: " . $conn->connect_error);
    }
    #INSERT INTO `nnoble_grcc`.`users` (`first_name`, `last_name`, `email`, `pwdhash`) VALUES ('Neal', 'Noble', 'nrnoble@hotmail.com', 'asdfasdfafdasdfasdfasdf')
    $sql =   "INSERT INTO `nnoble_grcc`.`users` (`first_name`, `last_name`, `email`, `pwdhash`) VALUES ('" . $first_name . "', '" . $last_name . "', '" . $email ."', '" . $pwd1_hash . "')";


    $result = @mysqli_query($conn, $sql);
    if (!$result)
    {
        echo "<h2 style = 'color:red'>";
        echo "hash: $pwd1_hash";

        echo "<p>Error: " . mysqli_error($conn) . "</p>";
        print_r($_POST);
        echo "</h2>";

        return;

        header("Location: registered_list.php");


}

header("Location: registered_list.php");
?>
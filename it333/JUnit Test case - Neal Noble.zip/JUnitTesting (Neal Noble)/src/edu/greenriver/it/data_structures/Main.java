package edu.greenriver.it.data_structures;

public class Main {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		BagSet <Integer>set = new BagSet <>(5);
		set.add(10);
		set.add(20);
		set.add(30);
		
		System.out.println(set.size());
	
		System.out.println(set.contains(10));
		System.out.println(set.size());
		System.out.println(set.remove(10));
		System.out.println(set.contains(10));
		System.out.println(set.size());
		
		
	}

}

package edu.greenriver.it.data_structures;
import org.junit.*;
import org.junit.Test;

/*
�* Neal Noble
 * April 2017 
 * Assignment: JUnit Test cases
 * Instructor: Josh Archer
�*/


public class BagTest 
{
	BagSet<Integer> set;
	
	@Before
	public void setup()
	{
		 set = new BagSet<>(5);
	}
	
	@Test	
	public void testConstructor()
	{
		
	}
	
	@Test	
	public void testAdd()
	{
		set.add(10);
		set.add(20);
		set.add(30);
		
		Assert.assertEquals("The size() of the BagSet should be 3 after adding 3 elements", 3, set.size());
		
		set.add (10); // can not add duplicate element
	
		Assert.assertEquals("The size () if the BagSet should not have increased", 3, set.size());
		
		set.add(40);
		set.add(50);
		set.add(60); // this should not be added 
		
		
		Assert.assertEquals("The size of Bagset is incorrect.", 5, set.size());
			
	}
	
	
	@Test	
	public void testContains()
	{
		// verify elements inside the bag
		// verify that element are not not inside the bag
		
		set.add(10);

		// Verify that we can find an element that does  exist in the bag
		Assert.assertTrue("Contains() should return true if element is inside the back", set.contains(10));

		// Verify that we cannot find an element that does not exist in the bag
		Assert.assertFalse("Contains() should return true if element is inside the back", set.contains(20));	
	}
	
	@Test	
	public void testRemove()
	{
		set.add(10);
		set.add(20);
		set.add(30);
		
		set.remove(10);
		Assert.assertEquals("size should be decreased to 2 elements total", 2, set.size());
		
		System.out.println(set.size());
		
		
		boolean result = set.remove(20);
		Assert.assertTrue("size should be true when an element has been successfully removed", result);
		
		  result = set.remove(-10);
			Assert.assertFalse("Removing an elment that does not exist should return false", result);
			
		    result = set.remove(20);
			Assert.assertFalse("size should be true when an element has been successfully removed", result);
			
	}
	
	@Test	
	public void testSize()
	{
		//verify size is zero for no elements
		Assert.assertEquals("size should be  zero for no elements", 0, set.size());
	
		set.add(10);
		
		//verify size is increases when elements are added
		Assert.assertEquals("size should be  zero for no elements", 1, set.size());
		
		set.add(20);
		Assert.assertEquals("size should be increased to 2", 2, set.size());
		
		set.remove(10);
		Assert.assertEquals("size should be decreased to 1", 1, set.size());
		
		set.remove(20);
		Assert.assertEquals("size should be decreased to zero", 0, set.size());
		
	}

}

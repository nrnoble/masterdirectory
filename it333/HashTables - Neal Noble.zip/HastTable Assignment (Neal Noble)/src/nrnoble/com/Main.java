package nrnoble.com;

public class Main {

    public static void main(String[] args)
    {
	// write your code here

        HastTable<String> wordset = new HastTable<>();

        wordset.add("red");
        wordset.add("black");
        wordset.add("blue");
        wordset.add("green");
        wordset.add("white");
        wordset.add("pink");

        System.out.println("Before reshash(): " + wordset.toString());

        wordset.add("purple");

        System.out.println("After reshash(): " + wordset.toString());
        System.out.println("remove(red): " + wordset.remove("red"));
        System.out.println("size(): " + wordset.size());

        for (String word: wordset)
        {
            System.out.println(word);
            //wordset.remove("pink");
        }
    }
}

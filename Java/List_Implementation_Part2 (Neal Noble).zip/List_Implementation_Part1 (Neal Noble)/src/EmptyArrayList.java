// Neal R Noble
// IT333
// April 2016
// Assignment - Assignment - List Implementation (Part one)

import java.util.*;

public class EmptyArrayList<T> implements List<T>
{
    // part #1 methods below...
    private static final int MAX_ARRAY_SIZE = Integer.MAX_VALUE - 1;
    private Object[] listOfElements;
    private static final int DEFAULT_ARRAY_SIZE = 50;
    private int elementCount;
    public transient int modCount = 0;


    public EmptyArrayList()
    {
        this.listOfElements = new Object[DEFAULT_ARRAY_SIZE];
    }

    /**
     * adds newElement to the uppermost index in the list. You should be able to repeatedly
     * add listOfElements to the list (it should always resize itself to make room for new listOfElements).
     *
     * @param newElement is the new object to be added
     * @return true if element has been added.
     */
    @Override
    public boolean add(T newElement)
    {
        //arraySizeHandler(DEFAULT_ARRAY_SIZE);

        // TODO: this solutions is very inefficient. Need to rework it so
        // that is does not call add(index,element)
        add(this.elementCount, newElement);
        //this.listOfElements[this.elementCount++] = newElement;
        return true;
    }


    /**
     * inserts newElement at the given index. All existing listOfElements should still be present
     * in the list after your insert newElement. Similar to add(), you should be able to
     * repeatedly add listOfElements to the list (it should always resize itself to make room for new listOfElements).
     *
     * @param index      of where to insert element
     * @param newElement is the new object to be inserted into array
     */
    @Override
    public void add(int index, T newElement)
    {

        if (index > this.elementCount || index < 0)
            throw new IndexOutOfBoundsException("Array elementCount: " +
                    this.elementCount + " Current index: " + index);

        arraySizeHandler(this.elementCount + 1);
        System.arraycopy(listOfElements, index, this.listOfElements, index + 1, this.elementCount - index);
        this.listOfElements[index] = newElement;
        elementCount++;
    }


    /**
     * Check of List is empty
     *
     * @return true if your list is empty, otherwise false.
     */
    @Override
    public boolean isEmpty()
    {
        if (this.elementCount == 0)
            return true;

        return false;
    }


    /**
     * Size of List
     *
     * @return the number of listOfElements in the list.
     */
    @Override
    public int size()
    {
        return this.elementCount;
    }


    /**
     * removes all listOfElements in the list.
     */
    @Override
    public void clear()
    {
        elementCount = 0;
        this.listOfElements = new Object[DEFAULT_ARRAY_SIZE];
    }


    /**
     * returns the index of the first occurrence of search in the list.
     * If search is not found, then indexOf() should return -1.
     *
     * @param search element
     * @return index of element. -1 if element is not found
     */
    @Override
    public int indexOf(Object search)
    {
        // do a check of null to avoid throwing an exception
        if (search == null) {
            for (int index = 0; index < elementCount; index++)
                if (this.listOfElements[index] == null) {
                    return index;
                }
        } else {
            for (int index = 0; index < elementCount; index++)
                if (search.equals(this.listOfElements[index])) {
                    return index;
                }
        }
        return -1;
    }


    /**
     * Check if element is in list
     *
     * @param search element
     * @return true if element exists
     */
    @Override
    public boolean contains(Object search)
    {
        if (indexOf(search) >= 0)
            return true;

        return false;
    }


    /**
     * Get element from list
     *
     * @param index add element at index
     * @return element that has been added
     */
    @Override
    public T get(int index)
    {
        if (boundaryCheck(index))
            return (T) this.listOfElements[index];

        return null;
    }


    /**
     * @param index add element at index
     * @param value element to be added
     * @return element that has been added
     */
    @Override
    public T set(int index, T value)
    {
        if (this.boundaryCheck(index)) {
            this.listOfElements[index] = value;
            return value;
        }
        return value;
    }


    /**
     * removes the first occurrence of search in the list. Returns true if the listOfElements
     * was found, otherwise false.
     *
     * @param search is the element to be removed
     * @return true if element has been removed
     */
    @Override
    public boolean remove(Object search)
    {
        this.removeElement(indexOf(search));
        return true;
    }

    /**
     * remove element by index
     *
     * @param index of element to be removed from list
     * @return null
     */
    @Override
    public T remove(int index)
    {
        this.removeElement(index);
        return null;
    }


    private void increaseArray_size(int minArraySize)
    {

        int currentArrayLength = this.listOfElements.length;
        int increaseArraySize = currentArrayLength + (currentArrayLength >> 1);
        if (increaseArraySize - minArraySize < 0) {
            increaseArraySize = minArraySize;
        }

        if (increaseArraySize - this.MAX_ARRAY_SIZE > 0) {
            increaseArraySize = this.MAX_ARRAY_SIZE;
        }

        listOfElements = Arrays.copyOf(this.listOfElements, increaseArraySize);
    }


    private boolean boundaryCheck(int _index)
    {
        if (_index > this.elementCount || _index < 0)
            throw new IndexOutOfBoundsException("Array elementCount: " + elementCount + " Current index: " + _index);

        return true;
    }


    private void arraySizeHandler(int _min)
    {
        Object[] defaultSize = {};
        if (listOfElements == defaultSize) {
            _min = Math.max(this.DEFAULT_ARRAY_SIZE, _min);
        }

        listrSizeHandler(_min);
    }

    private void listrSizeHandler(int _min)
    {
        this.modCount++;

        if (_min - this.listOfElements.length > 0)
            this.increaseArray_size(_min);
    }

    private void removeElement(int index)
    {
        this.modCount++;
        int num = this.elementCount - index - 1;
        if (num > 0) {
            System.arraycopy(this.listOfElements,
                    index + 1,
                    this.listOfElements, index,
                    num);
        }

        this.listOfElements[--elementCount] = null;

    }


    // part #2 methods below...

    @Override
    public boolean addAll(Collection<? extends T> other)
    {

        return addAll(this.size(), other);
    }

    @Override
    public boolean addAll(int index, Collection<? extends T> other)
    {

        boundaryCheck(index);
        boolean modified = false;
        for (T element : other) {
            add(index++, element);
            modified = true;
        }
        return modified;
    }

    @Override
    public boolean containsAll(Collection<?> other)
    {
        for (int i = 0; i < other.size(); i++) {
            for (Object element2 : this) {
                if (other.toArray()[i] == element2)
                    break;
                else
                    return false;
            }
        }


        return true;
    }

    @Override
    public boolean removeAll(Collection<?> other)
    {
        //Objects.requireNonNull(other);
        return batchRemove(other, false);
    }


    @Override
    public boolean retainAll(Collection<?> other)
    {
        Objects.requireNonNull(other);
        return batchRemove(other, true);
    }

    @Override
    public List<T> subList(int fromIndex, int toIndex)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public Object[] toArray()
    {
            Object[] r = new Object[size()];
            Iterator<T> it = iterator();
            for (int i = 0; i < r.length; i++)
            {
                if (! it.hasNext()) // fewer elements than expected
                    return Arrays.copyOf(r, i);
                      r[i] = it.next();
            }
             return it.hasNext() ? finishToArray(r, it) : r;
    }

    @Override
    @SuppressWarnings("hiding")
    public <T> T[] toArray(T[] toFill)
    {
        int size = size();
        T[] r = toFill.length >= size ? toFill :
                (T[])java.lang.reflect.Array
                        .newInstance(toFill.getClass().getComponentType(), size);
        Iterator<T> it = iterator();

        for (int i = 0; i < r.length; i++)
        {
            if (! it.hasNext())
            {
                if (toFill != r)
                    return Arrays.copyOf(r, i);
                r[i] = null;
                return r;
            }
            r[i] = (T)it.next();
        }
        return it.hasNext() ? finishToArray(r, it) : r;
    }

    @Override
//    public Iterator<T> iterator()
//    {
//        return listIterator();
//    }



    // extra credit below...

    @Override
    public ListIterator<T> listIterator(int index)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }


    @Override
    public int lastIndexOf(Object search)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }



    @Override
    public ListIterator<T> listIterator()
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    //    @Override
    //    public ListIterator<> listIterator(final int index)
    //    {
    //        checkForComodification();
    //        boundaryCheck(index);
    //
    //        return new ListIterator<E>() {
    //            private final ListIterator<E> i = l.listIterator(index+offset);
    //
    //            public boolean hasNext() {
    //                return nextIndex() < size;
    //            }
    //
    //            public E next() {
    //                if (hasNext())
    //                    return i.next();
    //                else
    //                    throw new NoSuchElementException();
    //            }
    //
    //            public boolean hasPrevious() {
    //                return previousIndex() >= 0;
    //            }
    //
    //            public E previous() {
    //                if (hasPrevious())
    //                    return i.previous();
    //                else
    //                    throw new NoSuchElementException();
    //            }
    //
    //            public int nextIndex() {
    //                return i.nextIndex() - offset;
    //            }
    //
    //            public int previousIndex() {
    //                return i.previousIndex() - offset;
    //            }
    //
    //            public void remove() {
    //                i.remove();
    //                SubList.this.modCount = l.modCount;
    //                this.elementCount--;
    //            }
    //
    //            public void set(E e) {
    //                i.set(e);
    //            }
    //
    //            public void add(E e) {
    //                i.add(e);
    //                SubList.this.modCount = l.modCount;
    //                elementCount++;
    //            }
    //        };

    private boolean batchRemove(Collection<?> c, boolean _comp)
    {
        final Object[] localListOfElements = this.listOfElements;
        int r = 0, w = 0;
        boolean modified = false;
        try {
            for (; r < this.elementCount; r++)
                if (c.contains(localListOfElements[r]) == _comp)
                    localListOfElements[w++] = localListOfElements[r];
        } finally {

            if (r != this.elementCount) {
                System.arraycopy(localListOfElements, r,
                        localListOfElements, w,
                        this.elementCount - r);
                w += this.elementCount - r;
            }
            if (w != this.elementCount) {

                for (int i = w; i < this.elementCount; i++)
                    localListOfElements[i] = null;
                modCount += this.elementCount - w;
                this.elementCount = w;
                modified = true;
            }
        }
        return modified;
    }


    private static <T> T[] finishToArray(T[] r, Iterator<?> it) {
        int i = r.length;
        while (it.hasNext()) {
            int cap = r.length;
            if (i == cap) {
                int newCap = ((cap / 2) + 1) * 3;
                if (newCap <= cap) { // integer overflow
                    if (cap == Integer.MAX_VALUE)
                        throw new OutOfMemoryError
                                ("Required array size too large");
                    newCap = Integer.MAX_VALUE;
                }
                r = Arrays.copyOf(r, newCap);
            }
            r[i++] = (T)it.next();
        }
        // trim if overallocated
        return (i == r.length) ? r : Arrays.copyOf(r, i);
    }
}






class SubList<T> extends EmptyArrayList<T> {
    private final EmptyArrayList<T> l;
    private final int offset;
    private int size;

    SubList(EmptyArrayList<T> list, int fromIndex, int toIndex) {
        if (fromIndex < 0)
            throw new IndexOutOfBoundsException("fromIndex = " + fromIndex);
        if (toIndex > list.size())
            throw new IndexOutOfBoundsException("toIndex = " + toIndex);
        if (fromIndex > toIndex)
            throw new IllegalArgumentException("fromIndex(" + fromIndex +
                    ") > toIndex(" + toIndex + ")");
        l = list;
        offset = fromIndex;
        size = toIndex - fromIndex;
        this.modCount = l.modCount;
    }

    public T set(int index, T element) {
        rangeCheck(index);
        checkForComodification();
        return l.set(index+offset, element);
    }

    public T get(int index) {
        rangeCheck(index);
        checkForComodification();
        return l.get(index+offset);
    }

    public int size() {
        checkForComodification();
        return size;
    }

    public void add(int index, T element) {
        rangeCheckForAdd(index);
        checkForComodification();
        l.add(index+offset, element);
        this.modCount = l.modCount;
        size++;
    }

    public T remove(int index) {
        rangeCheck(index);
        checkForComodification();
        T result = l.remove(index+offset);
        this.modCount = l.modCount;
        size--;
        return result;
    }

//    protected void removeRange(int fromIndex, int toIndex) {
//        checkForComodification();
//        l.removeRange(fromIndex+offset, toIndex+offset);
//        this.modCount = l.modCount;
//        size -= (toIndex-fromIndex);
//    }

    public boolean addAll(Collection<? extends T> c) {
        return addAll(size, c);
    }

    public boolean addAll(int index, Collection<? extends T> c) {
        rangeCheckForAdd(index);
        int cSize = c.size();
        if (cSize==0)
            return false;

        checkForComodification();
        l.addAll(offset+index, c);
        this.modCount = l.modCount;
        size += cSize;
        return true;
    }

    public Iterator<T> iterator() {
        return listIterator();
    }

    public ListIterator<T> listIterator(final int index) {
        checkForComodification();
        rangeCheckForAdd(index);

        return new ListIterator<T>() {
            private final ListIterator<T> i = l.listIterator(index+offset);

            public boolean hasNext() {
                return nextIndex() < size;
            }

            public T next() {
                if (hasNext())
                    return i.next();
                else
                    throw new NoSuchElementException();
            }

            public boolean hasPrevious() {
                return previousIndex() >= 0;
            }

            public T previous() {
                if (hasPrevious())
                    return i.previous();
                else
                    throw new NoSuchElementException();
            }

            public int nextIndex() {
                return i.nextIndex() - offset;
            }

            public int previousIndex() {
                return i.previousIndex() - offset;
            }

            public void remove() {
                i.remove();
                SubList.this.modCount = l.modCount;
                size--;
            }

            public void set(T e) {
                i.set(e);
            }

            public void add(T e) {
                i.add(e);
                SubList.this.modCount = l.modCount;
                size++;
            }
        };
    }

    public List<T> subList(int fromIndex, int toIndex) {
        return new SubList<>(this, fromIndex, toIndex);
    }

    private void rangeCheck(int index) {
        if (index < 0 || index >= size)
            throw new IndexOutOfBoundsException(outOfBoundsMsg(index));
    }

    private void rangeCheckForAdd(int index) {
        if (index < 0 || index > size)
            throw new IndexOutOfBoundsException(outOfBoundsMsg(index));
    }

    private String outOfBoundsMsg(int index) {
        return "Index: "+index+", Size: "+size;
    }

    private void checkForComodification() {
        if (this.modCount != l.modCount)
            throw new ConcurrentModificationException();
    }
}

class RandomAccessSubList<E> extends SubList<E> implements RandomAccess {
    RandomAccessSubList(EmptyArrayList<E> list, int fromIndex, int toIndex) {
        super(list, fromIndex, toIndex);
    }

    public List<E> subList(int fromIndex, int toIndex) {
        return new RandomAccessSubList<>(this, fromIndex, toIndex);
    }
}
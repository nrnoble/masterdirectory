public class Main {

    public static void main(String[] args)
    {
        EmptyArrayList<String> testList = new EmptyArrayList<String>();


        ListTester.testAdd(testList);
        ListTester.testClear(testList);
        ListTester.testIsEmpty(testList);
        ListTester.testInsert(testList);

        ListTester.testContains(testList);
        ListTester.testGet(testList);
        ListTester.testIndexOf(testList);

        ListTester.testRemoveElement(testList);
        ListTester.testRemoveIndex(testList);
        ListTester.testSet(testList);
        ListTester.testSize(testList);

        ListTester.testRemoveAll(testList);
       // ListTester.testContainsAll(testList);



    }
}

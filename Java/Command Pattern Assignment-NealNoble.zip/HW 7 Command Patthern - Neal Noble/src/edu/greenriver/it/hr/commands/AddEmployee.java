/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - HR Command Pattern
 */

package edu.greenriver.it.hr.commands;

import edu.greenriver.it.hr.employees.Employee;

/**
 * Add an employee
 */
public class AddEmployee extends HRCommand
{
    public AddEmployee(Employee employee)
    {
        super(employee);
    }

    public void Execute()
    {

    }
}

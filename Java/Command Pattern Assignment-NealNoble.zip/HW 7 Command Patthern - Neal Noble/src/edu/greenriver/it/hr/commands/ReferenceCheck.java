/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - HR Command Pattern
 */

package edu.greenriver.it.hr.commands;

import edu.greenriver.it.hr.OfficeStaff;
import edu.greenriver.it.hr.employees.Employee;

/**
 * Performan a background check
 */
public class ReferenceCheck extends HRCommand
{
    public ReferenceCheck(Employee employee)
    {
        super(employee);
    }

    public void Execute()
    {
        OfficeStaff.referenceCheck(this.employee);
    }
}

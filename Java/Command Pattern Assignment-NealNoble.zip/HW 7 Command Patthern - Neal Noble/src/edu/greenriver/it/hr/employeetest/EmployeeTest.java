/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - HR Command Pattern
 */

package edu.greenriver.it.hr.employeetest;

import edu.greenriver.it.hr.HumanResources;

public class EmployeeTest
{
    public static void main(String[] args)
    {

        assignmentHeader();

        //test hiring process
        HumanResources hr = new HumanResources();
        hr.testHiringProcess();
    }


    /**
     * Assignment Header
     *
     */
    public static void assignmentHeader()
    {
        System.out.println();
        System.out.println("Neal Noble");
        System.out.println("IT426 - Command Pattern Assignment");
        System.out.println("Instructor: Josh Archer");
        System.out.println("Nov 2016");
        System.out.println();
    }

}



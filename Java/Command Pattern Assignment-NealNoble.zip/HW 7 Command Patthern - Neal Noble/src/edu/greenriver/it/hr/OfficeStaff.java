/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - HR Command Pattern
 */

package edu.greenriver.it.hr;

import edu.greenriver.it.hr.employees.Employee;
import edu.greenriver.it.hr.employees.EmployeeType;

import java.util.Random;

public class OfficeStaff
{
    public static Random random = new Random();
    
    public static void backgroundCheck(Employee employee)
    {
       employee.setPassBackgroundCheck("success!");
    }
    
    public static void referenceCheck(Employee employee)
    {
        employee.setPassRefenenceCheck("success!"); //100% chance to be a good reference
    }
    
    public static void changeEmployeeStatus(Employee employee, EmployeeType type)
    {
            employee.setType(type);
    }
}

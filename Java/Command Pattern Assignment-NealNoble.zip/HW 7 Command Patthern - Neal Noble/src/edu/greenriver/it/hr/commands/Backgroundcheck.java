/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - HR Command Pattern
 */

package edu.greenriver.it.hr.commands;


import edu.greenriver.it.hr.OfficeStaff;
import edu.greenriver.it.hr.employees.Employee;

public class Backgroundcheck extends HRCommand
{
    public Backgroundcheck(Employee employee)
    {
        super(employee);
    }

    public void Execute()
    {
        OfficeStaff.backgroundCheck(this.employee);
    }
}

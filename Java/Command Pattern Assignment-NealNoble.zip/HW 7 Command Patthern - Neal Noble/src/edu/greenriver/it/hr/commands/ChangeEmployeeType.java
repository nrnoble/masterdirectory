/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - HR Command Pattern
 */

package edu.greenriver.it.hr.commands;

import edu.greenriver.it.hr.OfficeStaff;
import edu.greenriver.it.hr.employees.Employee;
import edu.greenriver.it.hr.employees.EmployeeType;

/**
 *  Set employee type
 */
public class ChangeEmployeeType extends HRCommand
{
    public ChangeEmployeeType(Employee employee)
    {
        super(employee);
    }

    public void Execute()
    {
        if (OfficeStaff.random.nextInt(2) == 1)
        {
            OfficeStaff.changeEmployeeStatus(this.employee, EmployeeType.HOURLY);
        }
        else
        {
            OfficeStaff.changeEmployeeStatus(this.employee, EmployeeType.SALARY);
        }

        return;
    }
}

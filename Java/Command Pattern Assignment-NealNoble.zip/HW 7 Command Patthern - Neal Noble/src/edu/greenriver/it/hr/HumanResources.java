/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - HR Command Pattern
 */


package edu.greenriver.it.hr;

import java.util.*;

import edu.greenriver.it.hr.commands.*;
import edu.greenriver.it.hr.employees.Employee;
import edu.greenriver.it.hr.employeetest.TestData;

public class HumanResources
{
    //list of commands to complete (first come, first serve)
    private List<HRCommand> todos = new ArrayList<HRCommand>();
    
    //list of Employees
    private Map<String, Employee> namesToApplicants = new TreeMap<String, Employee>();
    
    //public methods 
    
    public void testHiringProcess()
    {

        for (Employee employee: TestData.getNewHires())
        {
            addApplicant(employee);
        }


        printAllHiresWithType(namesToApplicants.values());


    }
    
    public void addApplicant(Employee employee)
    {
        namesToApplicants.put(employee.getName(), employee);
        new Backgroundcheck(employee).Execute();
        new ReferenceCheck(employee).Execute();
        new ChangeEmployeeType(employee).Execute();
        new AddEmployee(employee).Execute();
        new ConsoleOutput(employee).Execute();
        System.out.println();
    }





    public static void printAllHiresWithType(Collection<Employee> employees)
    {
        for (Employee employee : employees)
        {
            System.out.println(employee.toString());
        }
    }



}

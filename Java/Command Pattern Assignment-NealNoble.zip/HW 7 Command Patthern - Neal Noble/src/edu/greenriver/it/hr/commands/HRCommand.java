/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - HR Command Pattern
 */

package edu.greenriver.it.hr.commands;


//HRCommand should store the receiver object that each Command class will need (an Employee object)
//HRCommand should have the typical execute() method and it should be abstract

import edu.greenriver.it.hr.employees.Employee;

/**
 * Abstract class for HR command objects
 */
public abstract class HRCommand
{
    protected Employee employee;

    public HRCommand(Employee employee)
    {
        this.employee = employee;
    }

    public void Execute()
    {

    }

}

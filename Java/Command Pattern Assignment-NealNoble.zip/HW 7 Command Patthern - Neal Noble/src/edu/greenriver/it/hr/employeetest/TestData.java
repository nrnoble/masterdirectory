/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - HR Command Pattern
 */

package edu.greenriver.it.hr.employeetest;

import edu.greenriver.it.hr.employees.Employee;
import java.util.ArrayList;
import java.util.List;

public class TestData
{
    public static List<Employee> getNewHires ()
    {
        List<Employee> newHires = new ArrayList<Employee>();
        newHires.add(new Employee("Sue Martinez"));
        newHires.add(new Employee("Stacy Miller"));
        newHires.add(new Employee("Garrett Wilson"));
        newHires.add(new Employee("Francis Miller"));
        newHires.add(new Employee("Sue Rodriguez"));

        return newHires;
    }







}

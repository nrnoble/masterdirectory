/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - HR Command Pattern
 */

package edu.greenriver.it.hr.employees;

public enum EmployeeType
{
    HOURLY,
    SALARY
}

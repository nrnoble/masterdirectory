/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - HR Command Pattern
 */

package edu.greenriver.it.hr.employees;

/**
 *  Employee class
 */
public class Employee
{
    private String name;
    private String passBackgroundCheck;
    private String passRefenenceCheck;
    private EmployeeType type;


    /**
     *  Name of employee
     * @param name Name
     */
    public Employee(String name)
    {
        this.name = name;
    }
    

    /**
     * Get employee name
     * @return name
     */
    public String getName()
    {
        return name;
    }


    /**
     * Name of employee
     * @param name name
     */
    public void setName(String name)
    {
        this.name = name;
    }


    /**
     *  get emploeyee Type
     * @return EmployeeType
     */
    public EmployeeType getType()
    {
        return type;
    }


    /**
     * Set Type of employee
     * @param type EmployeeType
     */
    public void setType(EmployeeType type)
    {
        this.type = type;
    }


    /**
     * Get results of background check
     * @return true/false
     */
    public String isPassBackgroundCheck()
    {
        return passBackgroundCheck;
    }


    /**
     * Set results of background check
     * @param passBackgroundCheck true/false
     */
    public void setPassBackgroundCheck(String passBackgroundCheck)
    {
        this.passBackgroundCheck = passBackgroundCheck;
    }


    /**
     * Get results of reference check
     * @return true/false
     */
    public String isPassRefenenceCheck()
    {
        return passRefenenceCheck;
    }


    /**
     * Set results of reference check
     * @param passRefenenceCheck true/false
     */
    public void setPassRefenenceCheck(String passRefenenceCheck)
    {
        this.passRefenenceCheck = passRefenenceCheck;
    }


    /**
     * Return name and employee type as string
     * @return name, type
     */
    public String toString()
    {
        return name + " (" + type + ")";
    }



}



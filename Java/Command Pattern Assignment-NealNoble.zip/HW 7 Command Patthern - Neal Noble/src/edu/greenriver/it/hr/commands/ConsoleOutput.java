/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - HR Command Pattern
 */

package edu.greenriver.it.hr.commands;


import edu.greenriver.it.hr.employees.Employee;

public class ConsoleOutput extends HRCommand
{

//    Hiring new employee: Sue Martinez
//    Starting background check... success!
//    Starting reference check... success!
//    Employee status changed to HOURLY
//    New employee added to system


    public ConsoleOutput(Employee employee)
    {
        super(employee);
    }

    public void Execute()
    {
        System.out.println("Hiring new employee: " + employee.getName());
        System.out.println("Starting background check..." + employee.isPassBackgroundCheck());
        System.out.println("Starting reference check..." + employee.isPassRefenenceCheck());
        System.out.println("Employee status changed to " + employee.getType());
        System.out.println("New employee added to system");
    }

    @Override
    public String toString()
    {
        return super.toString();
    }
}

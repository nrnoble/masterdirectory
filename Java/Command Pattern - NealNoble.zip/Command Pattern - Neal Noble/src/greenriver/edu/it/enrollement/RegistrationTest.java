/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Command Pattern
 */


package greenriver.edu.it.enrollement;

import greenriver.edu.it.Commands.CommandType;
import greenriver.edu.it.Commands.DropCommand;
import greenriver.edu.it.Commands.ICommand;
import greenriver.edu.it.Commands.RegisterCommand;
import greenriver.edu.it.registrations.GRClass;
import greenriver.edu.it.registrations.Student;

import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;
import java.util.concurrent.LinkedBlockingQueue;

public class RegistrationTest
{
    private static Queue<ICommand> commandsQueue = new LinkedBlockingQueue<ICommand>();
    private static Stack<ICommand> undoStack = new Stack<ICommand>();
    private static Scanner  console = new Scanner(System.in);
    private static Student[] students;
    private static GRClass[] Classes;


    /**
     *  Start of application
     * @param args vars passed to application
     */
    public static void main(String[] args)
    {
        students = getStudents();
        Classes = getClasses();

        
        assignmentHeader();
        
        System.out.println("Run Unit Tests");
        UnitTests();
        System.out.println("-----------------------------------------------------");
        System.out.println();
        menuOptions();
        console.close();
    }

    /**
     * Add Test data, executed commands.
     */
    public static void UnitTests()
    {
        action ("Lindsey","IT 333", CommandType.REGISTER);
        action ("Tyler","IT 333", CommandType.REGISTER);
        action ("Joseph","IT 333", CommandType.REGISTER);
        action ("Lindsey","IT 426", CommandType.REGISTER);
        action ("Joseph","IT 333", CommandType.DROP);
        action ("Tyler","IT 426", CommandType.REGISTER);
        action ("Joseph","IT 426", CommandType.REGISTER);
        action ("Barack","IT 426", CommandType.REGISTER);
        action ("Joseph","IT 333", CommandType.REGISTER);
        executeQueueOfCommands();
        undoLastCommand();
        undoLastCommand();


    }

    /**
     * Helper function for testing. Create commands and adds them to the queue
     * @param studentName fictional student
     * @param grClassName fictional Class
     * @param command action
     */
    public static void action(String studentName, String grClassName, CommandType command)
    {

        if(command == CommandType.REGISTER)
        {
            RegisterStudent(studentName,grClassName);
        }

        if(command == CommandType.DROP)
        {
            DropStudent (studentName,grClassName);
        }
    }


    /**
     * print menu and get user choice
     */
    public static void menuOptions()
    {
        while(true)
        {
            printMenu();
            userChoice();
            System.out.println();
        }
    }


    /**
     * Display user menu on console
     */
    public static void printMenu()
    {

        System.out.println("Menu Options:");
        CommandType[] types = CommandType.values();
        for (int i = 0; i < types.length; i++)
        {
            System.out.println((i+1) + ": " + types[i].toString());
        }

        System.out.println("x: Execute all commands in queue");
        System.out.println("z: Undo last action");
    }

    /**
     * prompt user for menu choice
     */
    public static void userChoice()
    {
        String userChoice = console.nextLine();
        userChoice(userChoice);
    }


    /**
     *  process User choice
     * @param userChoice menu option selected by user
     */
    public static void userChoice(String userChoice)
    {
        switch (userChoice)
        {
            case "1":
                RegisterStudent();
                break;
            case "2":
                DropStudent();
                break;
            case "x":
                executeQueueOfCommands();
                break;
            case "z":
                undoLastCommand();
                break;
        }
    }


    /**
     *  Undo only the last command in queue
     */
    public static void undoLastCommand()
    {
        if (!undoStack.isEmpty())
        {
            ICommand last = undoStack.pop();
            last.unexecute();
        }
    }

    /**
     * Execute all command in queue
     */
    public static void executeQueueOfCommands()
    {
        while (!commandsQueue.isEmpty())
        {
            ICommand command = commandsQueue.remove();
            command.execute();
            undoStack.push(command);
        }
    }

    /**
     *
     * @param student fictional student
     * @param grClass fictional Class
     */
    public static void RegisterStudent(String student, String grClass)
    {
        ICommand register = new RegisterCommand(getStudentFromUser(student),getClassFromUser(grClass));
        commandsQueue.add(register);
    }

    /**
     * A student to command queue
     */
    public static void RegisterStudent()
    {
        ICommand register = new RegisterCommand(getStudentFromUser(),getClassFromUser());
        commandsQueue.add(register);
    }

    /**
     * Add drop student to command queue
     * @param student fictional student
     * @param grClass fictional class
     */
    public static void DropStudent(String student, String grClass)
    {
        ICommand drop = new DropCommand(getStudentFromUser(student),getClassFromUser(grClass));
        commandsQueue.add(drop);
    }

    /**
     * Add drop student to command queue
     */
    public static void DropStudent()
    {
        ICommand drop = new DropCommand(getStudentFromUser(),getClassFromUser());
        commandsQueue.add(drop);
    }


    /**
     * Get GRClass Prompt user for Class name.
     * @return GRClass
     */
    public static GRClass getClassFromUser()
    {
        System.out.println("Enter a Class Name:");
        String ClassName = console.nextLine();
        return getClassFromUser(ClassName);
    }

    /**
     * Get GRClass by nanme
     * @param ClassName fictional student
     * @return GRClass fictional class
     */
    public static GRClass getClassFromUser(String ClassName)
    {
        for (int i = 0; i < Classes.length; i++)
        {
            if (Classes[i].getName().equals(ClassName))
            {
                return Classes[i];
            }
        }

        throw new IllegalStateException("Error finding Class: " + ClassName);
    }

    /**
     *  Prompt for name. Get Student by name
     * @return Student Object
     */

    public static Student getStudentFromUser()
    {
        System.out.println("Enter a Student Name:");
        String studentName = console.nextLine();
        return  getStudentFromUser(studentName);
    }


    /**
     *  Get Student by name
     * @param studentName fictional student
     * @return Student Object
     */
    public static Student getStudentFromUser(String studentName)
    {
        for (int i = 0; i < students.length; i++)
        {
            if (students[i].getName().equals(studentName))
            {
                return students[i];
            }
        }

        throw new IllegalStateException("Error finding Students: " + studentName);
    }


    /**
     * Test Data. Fictional Classes.
     * @return array of GRCLass objects
     */
    public static GRClass[] getClasses()
    {
        GRClass[] grClasses = new GRClass[3];
        grClasses[0] = new GRClass("IT 426", "TC 120", 4);
        grClasses[1] = new GRClass("IT 333", "TC 206", 4);
        grClasses[2] = new GRClass("IT 301", "TC 309", 4);

        return grClasses;
    }

    /**
     * Test Data. Fictional Students
     * @return array of Students objects
     */
    public static Student[] getStudents()
    {
        Student[] Students = new Student[5];
        Students[0] = new Student("Lindsey");
        Students[1] = new Student("Tyler");
        Students[2] = new Student("Joseph");
        Students[3] = new Student("Barack");

        return Students;
    }
    
    
    /**
     * Assignment Header
     *
     */
    public static void assignmentHeader()
    {
        System.out.println();
        System.out.println("Neal Noble");
        System.out.println("IT426 - Factory Pattern Assignment");
        System.out.println("Instructor: Josh Archer");
        System.out.println("Nov 2016");
        System.out.println();


    }

    
}



package greenriver.edu.it;

public class Main
{

    public static void main(String[] args)
    {
    	greenriver.edu.it.enrollement.RegistrationTest.main(null);
    }
}

/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Command Pattern
 */

package greenriver.edu.it.registrations;


public class Student
{
    private String name;

    public Student(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String toString()
    {
        return this.name;
    }
}

/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Command Pattern
 */

package greenriver.edu.it.registrations;



import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GRClass
{
    private String name;
    private String location;
    private int seats;

    private List<Student> enrolledStudents = new ArrayList<Student>();
    private List<Student> waitListStudents = new ArrayList<Student>();

    public GRClass(String name, String location, int seats)
    {
        this.name = name;
        this.location = location;
        this.seats = seats;
    }

    public boolean registerStudent( Student student)
    {
        if (!hasStudent(student))
        {
            if (enrolledStudents.size() == seats)
            {
                waitListStudents.add(student);
            } else
            {
                enrolledStudents.add(student);
            }

            return true;
        }

        return false;
    }

    public boolean dropStudent (Student student)
    {
        if (hasStudent(student))
        {
            if (waitListStudents.contains(student))
            {
                waitListStudents.remove(student);
            }
            else
            {
                waitListStudents.remove(student);

                if(waitListStudents.size() > 0)
                {
                    enrolledStudents.add(waitListStudents.get(0));
                }
            }
            return true;
        }
        return false;
    }

    public boolean hasStudent (Student student)
    {
        return enrolledStudents.contains(student) || waitListStudents.contains(student);
    }


    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getLocation()
    {
        return location;
    }

    public void setLocation(String location)
    {
        this.location = location;
    }

    public int getSeats()
    {
        return seats;
    }

    public void setSeats(int seats)
    {
        this.seats = seats;
    }

    public List<Student> getEnrolledStudents()
    {
        return Collections.unmodifiableList(enrolledStudents);
    }

    public void setEnrolledStudents(List<Student> enrolledStudents)
    {
        this.enrolledStudents = enrolledStudents;
    }

    public List<Student> getWaitListStudents()
    {
        return Collections.unmodifiableList(waitListStudents);
    }

    public void setWaitListStudents(List<Student> waitListStudents)
    {
        this.waitListStudents = waitListStudents;
    }


    public String toString()
    {
        return name;
    }
}

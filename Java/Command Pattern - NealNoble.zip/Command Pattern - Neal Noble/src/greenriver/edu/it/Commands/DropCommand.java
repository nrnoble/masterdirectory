/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Command Pattern
 */

package greenriver.edu.it.Commands;


import greenriver.edu.it.registrations.GRClass;
import greenriver.edu.it.registrations.Student;

public class DropCommand extends AbstractEnrollmentCommand
{
    private boolean somethingChanged = false;


    public DropCommand(Student student, GRClass grClass)
    {
        super(student, grClass);
    }

    @Override
    public void execute()
    {
        somethingChanged = grClass.dropStudent(student);
        System.out.println(student.getName() +  "  has dropped " + grClass.getName());
    }

    @Override
    public void unexecute()
    {
        if (somethingChanged)
        {
            grClass.registerStudent(student);
            System.out.println(student.getName() +  "  has added back to " + grClass.getName());
        }
    }
}

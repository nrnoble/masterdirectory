/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Command Pattern
 */

package greenriver.edu.it.Commands;

/**
 * Intergaces for the the the command objects
 */
public interface ICommand
{
    public void execute ();
    public void unexecute ();
}

/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Command Pattern
 */

package greenriver.edu.it.Commands;

/**
 * Enum for the types of commands available
 *
 */
public enum CommandType
{
    REGISTER,
    DROP
}

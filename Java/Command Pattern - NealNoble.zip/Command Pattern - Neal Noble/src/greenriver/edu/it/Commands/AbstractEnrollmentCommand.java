/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Command Pattern
 */

package greenriver.edu.it.Commands;

import greenriver.edu.it.registrations.GRClass;
import greenriver.edu.it.registrations.Student;


public class AbstractEnrollmentCommand implements ICommand
{
    protected Student student;
    protected GRClass grClass;

    /**
     *  Constructor
     * @param student fictional student
     * @param grClass fictional class
     */
    public AbstractEnrollmentCommand(Student student, GRClass grClass)
    {
        this.student = student;
        this.grClass = grClass;
    }


    /**
     *  Interface
     */
    @Override
    public void execute()
    {

    }

    /**
     *  Interface
     */
    @Override
    public void unexecute()
    {

    }
}

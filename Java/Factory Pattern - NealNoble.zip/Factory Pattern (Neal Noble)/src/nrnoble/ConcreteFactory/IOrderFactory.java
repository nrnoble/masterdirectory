/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Factory Pattern
 */


package nrnoble.ConcreteFactory;
import nrnoble.ShippingRate.IShippingRate;
import nrnoble.TaxCaculators.ISalesTax;

public interface IOrderFactory
{

    ISalesTax getTaxObject();
    IShippingRate getRateObject();
}

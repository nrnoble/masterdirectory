/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Factory Pattern
 */


package nrnoble.ConcreteFactory;

import nrnoble.ShippingRate.EUShippingRate;
import nrnoble.ShippingRate.IShippingRate;
import nrnoble.TaxCaculators.EUSalesTax;
import nrnoble.TaxCaculators.ISalesTax;

public class UEOrderFactory implements IOrderFactory
{
    private ISalesTax euTaxRate;
    private IShippingRate euShippingRate;
    //private IShippingRate usShippingRate;

    public UEOrderFactory()
    {
        this.euTaxRate = new EUSalesTax();
        this.euShippingRate = new EUShippingRate();
    }

    @Override
    public ISalesTax getTaxObject()
    {
        return euTaxRate;
    }

    @Override
    public IShippingRate getRateObject()
    {
        return euShippingRate;
    }
}

/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Factory Pattern
 */


package nrnoble.ConcreteFactory;

import nrnoble.ShippingRate.IShippingRate;
import nrnoble.ShippingRate.USShippingRate;
import nrnoble.TaxCaculators.ISalesTax;
import nrnoble.TaxCaculators.USSalesTax;


public class USOrderFactory implements IOrderFactory
{

    private ISalesTax usTaxRate;
    private IShippingRate usShippingRate;


    public USOrderFactory()
    {
         this.usTaxRate = new USSalesTax();
         this.usShippingRate = new USShippingRate();
    }

    public ISalesTax getUsTaxRate()
    {
        return usTaxRate;
    }

    public IShippingRate getUsShippingRate()
    {
        return usShippingRate;
    }



    @Override
    public ISalesTax getTaxObject()
    {
        return usTaxRate;
    }

    @Override
    public IShippingRate getRateObject()
    {
        return usShippingRate;
    }
}

/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Factory Pattern
 */


package nrnoble.ShippingRate;

public interface IShippingRate
{
    public Rate getRate(String type, double weight);
}

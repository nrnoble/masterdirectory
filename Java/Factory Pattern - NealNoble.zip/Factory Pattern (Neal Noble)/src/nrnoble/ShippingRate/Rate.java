/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Factory Pattern
 */


package nrnoble.ShippingRate;


public class Rate
{

    private String shippingType ;
    private double rate;




    public Rate(String shippingType, double rate)
    {
        this.shippingType = shippingType;
        this.rate = rate;
    }


    public String getShippingType()
    {
        return shippingType;
    }

    /**
     * Get the shipping rate
     * @return shipping rate
     */
    public double getRate()
    {
        return rate;
    }




}

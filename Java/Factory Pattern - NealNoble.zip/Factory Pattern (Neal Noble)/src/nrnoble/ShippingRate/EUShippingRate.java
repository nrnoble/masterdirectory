
package nrnoble.ShippingRate;

public class EUShippingRate implements IShippingRate
{
    private Double euroPerLbs = 0.5;

    @Override
    public Rate getRate(String type, double weight)
    {
        return new Rate("EU", weight * euroPerLbs);
    }
}

/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Factory Pattern
 */


package nrnoble.ShippingRate;

public class USShippingRate implements IShippingRate
{


    public static enum usShippingType
    {
        Standard,
        Priority
    }

    @Override
    public Rate getRate(String type, double weight)
    {
        Rate rate;

        double PIORITY_SHIPPING_RATE = 3; // per lbs
        double ONE_LBS_SHIPPING_RATE = 1; // per standard item
        double FIVE_LBS_SHIPPING_RATE = 5; // per standard item
        double TEN_LBS_SHIPPING_RATE = 10; // per standard item
        double FIVETEEN_LBS_SHIPPING_RATE = 15; // per standard item


        // More efficient to calculate priority shipping first, exits method sooner.
        if (type.equals("Priority"))
        {
            rate = new Rate(type, weight * PIORITY_SHIPPING_RATE);
            return rate;
        }


        // shipping type must be usShippingType.Standard

        // Can't use switch statement on double variable types.
        // Create filter logic to simulate switch statement,
        // lowest weights are processed first, and shipping rate is returned when conditions are met based on weight.
        if (weight < ONE_LBS_SHIPPING_RATE) {
            rate = new Rate(type, ONE_LBS_SHIPPING_RATE);
            return rate;
        }

        // check between 1 - 5. Weight below one lbs never reaches here
        if (weight <= FIVE_LBS_SHIPPING_RATE) {
            rate = new Rate(type, FIVE_LBS_SHIPPING_RATE);
            return rate;
        }

        // check between 5 - 10. Weight below 5 lbs never reaches here
        if (weight <= TEN_LBS_SHIPPING_RATE) {
            rate = new Rate(type, TEN_LBS_SHIPPING_RATE);
            return rate;
        }


        // otherwise all weight over 10lbs has the same shipping costs
        rate = new Rate(type, FIVETEEN_LBS_SHIPPING_RATE);
        return rate;
    }

    /**
     * Calculate the US shipping cost
     *
     * @param shippingType either Standard or Piroity
     * @param weight       total weight of item to be shipped
     * @return USA shipping cost
     */
    public double calculateUSbyWeight(usShippingType shippingType, double weight)
    {
        double PIORITY_SHIPPING_RATE = 3; // per lbs
        double ONE_LBS_SHIPPING_RATE = 1; // per standard item
        double FIVE_LBS_SHIPPING_RATE = 5; // per standard item
        double TEN_LBS_SHIPPING_RATE = 10; // per standard item
        double FIVETEEN_LBS_SHIPPING_RATE = 15; // per standard item


        // More efficient to calculate priority shipping first, exits method sooner.
        if (shippingType == usShippingType.Priority) {
            return weight * PIORITY_SHIPPING_RATE;
        }


        // shipping type must be usShippingType.Standard

        // Can't use switch statement on double variable types.
        // Create filter logic to simulate switch statement,
        // lowest weights are processed first, and shipping rate is returned when conditions are met based on weight.
        if (weight < ONE_LBS_SHIPPING_RATE) {
            return ONE_LBS_SHIPPING_RATE;
        }

        // check between 1 - 5. Weight below one lbs never reaches here
        if (weight <= FIVE_LBS_SHIPPING_RATE) {
            return FIVE_LBS_SHIPPING_RATE;
        }

        // check between 5 - 10. Weight below 5 lbs never reaches here
        if (weight <= TEN_LBS_SHIPPING_RATE) {
            return TEN_LBS_SHIPPING_RATE;
        }


        // otherwise all weight over 10lbs has the same shipping costs
        return FIVETEEN_LBS_SHIPPING_RATE;

    }

}
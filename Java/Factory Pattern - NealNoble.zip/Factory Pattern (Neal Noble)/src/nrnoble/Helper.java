/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Factory Pattern
 */

package nrnoble;

import nrnoble.ShippingRate.Rate;

import java.text.NumberFormat;


public class Helper
{

    /**
     * Assignment Header
     *
     */
    public static void assignmentHeader()
    {
        System.out.println();
        System.out.println("Neal Noble");
        System.out.println("IT426 - Factory Pattern Assignment");
        System.out.println("Instructor: Josh Archer");
        System.out.println("Nov 2016");
        System.out.println();


    }

    /**
     * Post Office Header
     *
     */
    public static void PostOfficeHeader()
    {
        System.out.println("************************************");
        System.out.println("*        US POST OFFICE            *");
        System.out.println("*           SHIPPING               *");
        System.out.println("************************************");
        System.out.println();
    }

    /**
     *
     * @param orderName orderName
     * @param shippingType shippingType
     * @param weight weight
     * @param tax tax
     * @param ShippingRate  ShippingRate
     */
    public static void printInvoice(String orderName, String shippingType, double weight, double tax, Rate ShippingRate)
    {
        NumberFormat moneyFormat = NumberFormat.getCurrencyInstance();

        System.out.println();
        System.out.println();
        System.out.println("SHIPPING SUMMERY:");
        System.out.println();
        System.out.println("      Order Name: "  + orderName);
        System.out.println("   Shipping type: "  + shippingType);
        System.out.println("          weight: "  + weight + " lbs");
        System.out.println("   Shipping Cost: " + moneyFormat.format(ShippingRate.getRate()));
        System.out.println("             Tax: " + moneyFormat.format (tax));
        System.out.println("---------------------------------");
        double total = tax +ShippingRate.getRate();
        System.out.println("           Total: " + moneyFormat.format (total));
    }
}

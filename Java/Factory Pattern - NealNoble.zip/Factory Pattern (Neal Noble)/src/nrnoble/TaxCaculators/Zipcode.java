package nrnoble.TaxCaculators;


// Assignment: US tax is based on numerical zip code {98000, 93002, 99099}
public enum Zipcode
{
    zip_98000 (3.1),
    zip_93002 (2.5),
    zip_99099 (2.8);

    private double numVal;

    Zipcode(double numVal)
    {
        this.numVal = numVal;
    }

    public double getNumVal() {
        return numVal;
    }

}


package nrnoble.TaxCaculators;

/**
 * Factory Interface for sales tax
 *
 */
public interface ISalesTax
{
    double calculateTax (double salesSubTotal);
}

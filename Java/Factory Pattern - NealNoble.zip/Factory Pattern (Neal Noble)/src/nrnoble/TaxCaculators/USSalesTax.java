package nrnoble.TaxCaculators;

public class USSalesTax implements ISalesTax
{

    private String zipCode;
    private Double taxRate;



    public USSalesTax()
    {
    }

    /**
     *
     * @param zipCode zipcode of destination
     */
    public USSalesTax(String zipCode)
    {
         this.zipCode = zipCode;
         taxRate = Zipcodes.getZipcodeTaxRate(zipCode);
    }

    /**
     * ISalesTax interface
     * @param salesSubTotal shipping subtotal.
     * @return Tax amount
     */
    @Override
    public  double calculateTax(double salesSubTotal)
    {

        double tax = salesSubTotal * taxRate;
        return tax;
    }




    public String getZipCode()
    {
        return zipCode;
    }


    public void setZipCode(String zipCode)
    {
        this.zipCode = zipCode;
    }


    public Double getTaxRate()
    {
        return taxRate;
    }


    public void setTaxRate(Double taxRate)
    {
        this.taxRate = taxRate;
    }
}

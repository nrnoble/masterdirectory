/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Factory Pattern
 */

package nrnoble.TaxCaculators;

/**
 * EU Factory class that implements sales tax Interface
 *
 */
public class EUSalesTax implements ISalesTax
{

    Regions regions = new Regions();
    private String country;
    private Double taxRate;

    public EUSalesTax()
    {
    }

    /**
     * Constructor.
     *
     * @param country eu Country
     */
    public EUSalesTax(String country)
    {
        this.country = country;
        this.taxRate = Regions.getCountryTaxRate(country);
    }


    /**
     * Calcuate Tax amount
     *
     * @param salesSubTotal before tax amount
     * @return Tax amount
     */
    @Override
    public double calculateTax(double salesSubTotal)
    {

        double tax = salesSubTotal * this.taxRate;
        return tax;
    }



}
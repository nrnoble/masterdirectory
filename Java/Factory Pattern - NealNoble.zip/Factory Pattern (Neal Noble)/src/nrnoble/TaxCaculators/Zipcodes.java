package nrnoble.TaxCaculators;

import java.util.HashMap;
import java.util.Map;

public class Zipcodes
{
    public static Double getZipcodeTaxRate (String zipcode)
    {
       // HashMap<Integer, String> hmap = new HashMap<Integer, String>();
        HashMap<String, Double> zipCodes = new HashMap<String, Double>();
        zipCodes.put("98000", 7.8);
        zipCodes.put("93002", 7.9);
        zipCodes.put("99099", 8.0);
        zipCodes.put("98002", 8.1);
        double tax = 0;

        //HACK. Need to remove try-catch.
        // Assign default tax rate if zipcode is not found. Beyond scope of assignment
        // to code all zipcode. Maybe add a random tax rate generator to better simulate tax rates
        try
        {
            tax = zipCodes.get(zipcode);
        }
        catch (Exception exception)
        {
                tax = 7.9;
        }
        return (tax * 0.01);
    }

}

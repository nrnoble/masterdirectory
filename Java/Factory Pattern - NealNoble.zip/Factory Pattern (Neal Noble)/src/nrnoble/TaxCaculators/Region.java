package nrnoble.TaxCaculators;

// Assignment: EU tax is based on region {"germany", "france", "spain"},
public enum Region
{
    germany (2.9),
    france (3.2),
    spain (2.3);

    private double numVal;

    Region(double numVal)
    {
        this.numVal = numVal;
    }

    public double getNumVal() {
        return numVal;
    }
}


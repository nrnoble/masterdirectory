/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Factory Pattern
 */


package nrnoble;

import nrnoble.ConcreteFactory.IOrderFactory;
import nrnoble.ConcreteFactory.UEOrderFactory;
import nrnoble.ConcreteFactory.*;
import nrnoble.ShippingRate.IShippingRate;
import nrnoble.ShippingRate.Rate;
import nrnoble.TaxCaculators.EUSalesTax;
import nrnoble.TaxCaculators.ISalesTax;
import nrnoble.TaxCaculators.USSalesTax;

import java.text.NumberFormat;
import java.util.Scanner;

import static nrnoble.Helper.printInvoice;

public class Driver
{
//    Driver Class
//
//    Create a test class that prints out the tax, shipping rate and total for a user's order.
//
//    You should program your code against the abstract factory interface.
//    ie. IOrderFactory factory = new EUOrderFactory();
//    Prompt the user for a region to place an order in (ie. US or EU)
//    Prompt the user for an order name, weight and shipping type
//    Finally print the following based on the user's choice:
//    Order details: name, weight and shipping type
//    The shipping cost
//    The subtotal, tax and total of the order

    /**
     * Assignment Driver
     * @param args command line args
     */
    public static void main(String[] args)
    {
        Helper.assignmentHeader();

        // Factory Classes
        IShippingRate Shipping = null;
        ISalesTax TaxRate = null;
        Rate ShippingRate = null;
        ISalesTax SalesTax = null;

        //Defaults
        String euCountry = "france";
        String zipCode = "98002";
        String location = "us";
        String orderName = "OrderName-Test";
        Double weight = 11.34;
        String shippingType = "Standard";
        int choice = 0;
        boolean debug = false;
        double tax = 0;

        // Utility helpers
        Scanner console = new Scanner(System.in);
        NumberFormat moneyFormat = NumberFormat.getCurrencyInstance();


        Helper.PostOfficeHeader();


        // User Input Menu

        System.out.print("STEP 1: Order Name: ");
        orderName = console.nextLine();

        System.out.print("STEP 2: Weight of Package in lbs: ");
        weight = console.nextDouble();


        System.out.println("STEP 3: Select shipping destination: ");

        while ((choice != 1) && (choice != 2))
        {
            System.out.println("  1) United States ");
            System.out.println("  2) European Union");
            System.out.print("  Select: ");
            choice = console.nextInt();
        }
        zipCode = console.nextLine();

            // Choice ==1 is US

        if (choice == 1)
        {
            IOrderFactory usFactory = new USOrderFactory();
            IShippingRate usShipping = usFactory.getRateObject();
            ISalesTax usSalesTax = usFactory.getTaxObject();

            Shipping = usShipping;
            SalesTax = usFactory.getTaxObject();
            System.out.print("STEP 4: Destination Zipcode: ");
            zipCode = console.nextLine();

            choice = 0;
            System.out.println("STEP 5: Shipping type: ");
            while ((choice != 1) && (choice != 2))
            {
                System.out.println("  1) Standard ");
                System.out.println("  2) Priority");
                System.out.print  ("  Select: ");
                choice = console.nextInt();

                if  (choice == 1)
                {
                    shippingType = "Standard";
                    ShippingRate = Shipping.getRate(shippingType,weight);
                }
                else
                {
                    shippingType = "Priority";
                    ShippingRate = Shipping.getRate(shippingType,weight);
                }

                TaxRate = new USSalesTax(zipCode);
                tax = TaxRate.calculateTax(ShippingRate.getRate());
            }
        }
        else
        {

            IOrderFactory euFactory = new UEOrderFactory();
            IShippingRate EUShipping = euFactory.getRateObject();
            ISalesTax EUTaxRate = euFactory.getTaxObject();
            shippingType = "EU Flate @ 0.5 lbs per Euro";
            Shipping = EUShipping;
            TaxRate = EUTaxRate;



            System.out.print("STEP 4: Destination EU Country (ie France): ");
            euCountry = console.nextLine().toLowerCase();
            TaxRate = new EUSalesTax(euCountry);
            ShippingRate = Shipping.getRate(shippingType,weight);
            tax = TaxRate.calculateTax(ShippingRate.getRate());
            Rate euShippingRate = EUShipping.getRate("EU",ShippingRate.getRate());

        }


        printInvoice(orderName, shippingType, weight, tax, ShippingRate);



    }
}

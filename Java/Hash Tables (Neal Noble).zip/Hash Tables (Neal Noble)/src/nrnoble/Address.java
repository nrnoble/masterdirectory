package nrnoble;

/**
 * Created by Neal on 4/29/2016.
 */
public class Address
{




       private int number;
        private String street;
        private String city;
        private String state;
        private int zip;

        public Address(int number, String street, String city, String state, int zip)
        {
            this.number = number;
            this.street = street;
            this.city = city;
            this.state = state;
            this.zip = zip;
        }




    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Address address = (Address) o;

        if (number != address.number) return false;
        if (zip != address.zip) return false;
        if (street != null ? !street.equals(address.street) : address.street != null) return false;
        if (city != null ? !city.equals(address.city) : address.city != null) return false;
        return state != null ? state.equals(address.state) : address.state == null;

    }

    @Override
    public int hashCode()
    {
        int result = number;
        result = 31 * result + (street != null ? street.hashCode() : 0);
        result = 31 * result + (city != null ? city.hashCode() : 0);
        result = 31 * result + (state != null ? state.hashCode() : 0);
        result = 31 * result + zip;
        return result;
    }





       public int getNumber()
        {
            return number;
        }

        public void setNumber(int number)
        {
            this.number = number;
        }

        public String getStreet()
        {
            return street;
        }

        public void setStreet(String street)
        {
            this.street = street;
        }

        public String getCity()
        {
            return city;
        }

        public void setCity(String city)
        {
            this.city = city;
        }

        public String getState()
        {
            return state;
        }

        public void setState(String state)
        {
            this.state = state;
        }

        public int getZip()
        {
            return zip;
        }

        public void setZip(int zip)
        {
            this.zip = zip;
        }




}



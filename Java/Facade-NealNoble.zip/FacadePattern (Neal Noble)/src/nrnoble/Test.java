/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Facade Pattern
 */

package nrnoble;

import nrnoble.Part1.StringOperations;
import nrnoble.Part1.StringParsing;
import nrnoble.Part1.StringRegex;
import nrnoble.Part2.Facade;
import nrnoble.Part2.Operator;

import java.util.List;
import nrnoble.Helper;

public class Test
{
    public static String[] _stringArrayTestData;
    public static List<String> _listTestData;
    public static String divider = "------------------------------------------------------------------";
    public static String regExTestString  = "ABC-DEF-GHI-JKL-MNO-PQR-STU-VWX-YZ";



    public static void RemoveDuplicatesTest()
    {
        Helper.ResetStringArrayTestData();
        Helper.PrintSectionHeader("Resetting '_stringArrayTestData' Test data");

        Helper.PrintSectionHeader("Removing duplicates from _stringArrayTestData'");
        _stringArrayTestData = StringOperations.removeDuplicates(_stringArrayTestData);
        Helper.printStringArrayTestData();
    }



    public static void StringArrayFilterTest(String testItem)
    {
        Helper.PrintSectionHeader("Resetting TestData");

        _stringArrayTestData = Helper.generateStringArrayData(12);
        Helper.printStringArray(_stringArrayTestData);
        System.out.println();


        String[] strArrayTestData = StringOperations.filter(_stringArrayTestData,testItem);
        Helper.PrintSectionHeader("After: Filtered Data after item '"+ testItem +"' removed from _stringArrayTestData" );
        Helper.printStringArray(strArrayTestData);

        System.out.println();
    }


    public static void ListFilterTest(String testItem)
    {
        _listTestData = Helper.createListTestdata();
        Helper.printListTestData();
        System.out.println();
        System.out.println();

        Helper.PrintSectionHeader("After: Filtered Data after item '"+ testItem +"' removed from ListTestData" );
        _listTestData = StringOperations.filter(_listTestData,testItem);
        Helper.printListTestData();

        System.out.println();
    }


    public static void ResizeTest(int newSize)
    {
        Helper.ResetStringArrayTestData();
        _stringArrayTestData = StringOperations.Resize(_stringArrayTestData,newSize);

       Helper.PrintSectionHeader("'stringArrayTestData' has been resized to: " + newSize);
        Helper.printStringArray(_stringArrayTestData);
    }


    public static void Before(String subject, String delimiter)
    {
        Helper.PrintSectionHeader("Testing 'Before' method");
        String spilt = StringParsing.Before(subject,delimiter);
        System.out.println("Original String: " + subject);
        System.out.println("Delimiter: "+ delimiter);
        System.out.println("Split: " + spilt);
        System.out.println();

//        String result = regExTestString.split("4",2)[0];
//        Helper.PrintSectionHeader("String result = testString.split(\"4\",2)");
//        System.out.println(result);

    }


    public static void After(String subject, String delimiter)
    {
        //Helper.PrintSectionHeader("Testing 'After' method");
        String spilt = StringParsing.After(subject,delimiter);
        System.out.println("Original String: " + subject);
        System.out.println("Delimiter: "+ delimiter);
        System.out.println("Split: " + spilt);
        System.out.println();
    }


    public static boolean isEmail(String subject)
    {
        boolean result = StringRegex.isEmail(subject);
        Helper.PrintSectionHeader("result = StringRegex.isEmail(" + subject + ");");
        System.out.println("Result: " + result);
        System.out.println();
        return result;
    }


    public static boolean isZipCode(String subject)
    {
        boolean result = StringRegex.isZipCode(subject);
        Helper.PrintSectionHeader("result = StringRegex.isZipCode(" + subject + ");");
        System.out.println("Result: " + result);
        System.out.println();
        return result;
    }



    public static boolean isPhoneNumber(String subject)
    {
        boolean result = StringRegex.isPhoneNumber(subject);
        Helper.PrintSectionHeader("result = StringRegex.isPhoneNumber(" + subject + ");");
        System.out.println("Result: " + result);
        System.out.println();
        return result;
    }


    public static boolean isUrl(String subject)
    {
        boolean result = StringRegex.isUrl(subject);
        Helper.PrintSectionHeader("result = StringRegex.isUrl(" + subject + ");");
        System.out.println("Result: " + result);
        System.out.println();
        return result;
    }

    public static boolean Validate_Email(String subject)
    {
        Boolean result = Facade.validate(Facade.ValidationType.EMAIL, subject);
        Helper.PrintSectionHeader("Boolean result = Facade.validate(Facade.ValidationType.EMAIL, '" + subject + "')");
        System.out.println("result: "  + result);
        System.out.println();
        return result;
    }

    public static boolean Validate_PHONE_NUMBER(String subject)
    {
        Boolean result = Facade.validate(Facade.ValidationType.PHONE_NUMBER, subject);
        Helper.PrintSectionHeader("Boolean result = Facade.validate(Facade.ValidationType.PHONE_NUMBER, '" + subject + "')");
        System.out.println("result: "  + result);
        System.out.println();
        return result;
    }


    public static boolean Validate_ZIP_CODE(String subject)
    {
        Boolean result = Facade.validate(Facade.ValidationType.ZIP_CODE, subject);
        Helper.PrintSectionHeader("Boolean result = Facade.validate(Facade.ValidationType.ZIP_CODE, '" + subject + "')");
        System.out.println("result: "  + result);
        System.out.println();
        return result;
    }


    public static boolean Validate_URL(String subject)
    {
        Boolean result = Facade.validate(Facade.ValidationType.URL, subject);
        Helper.PrintSectionHeader("Boolean result = Facade.validate(Facade.ValidationType.URL, '" + subject + "')");
        System.out.println("result: "  + result);
        System.out.println();
        return result;
    }
    
    public static boolean Operator_removeDuplicates()
    {
        Operator operator = new Operator(Helper.generateStringArrayData(12));
        operator.removeDuplicates();
        Helper.PrintSectionHeader("operator.removeDuplicates();");

        Helper.printStringArray(operator.getSubject());
        System.out.println();
      return true;
    }



    public static boolean Operator_Filter(String search)
    {
        Operator operator = new Operator(Helper.generateStringArrayData(12));
        operator.filter(search);
        Helper.PrintSectionHeader("operator.filter(" + search + ")");

        Helper.printStringArray(operator.getSubject());
        System.out.println();
        return true;
    }


    public static boolean Operator_Resize(int reSize)
    {
        Operator operator = new Operator(Helper.generateStringArrayData(12));
        operator.Resize(reSize);
        Helper.PrintSectionHeader("operator.Resize(" + reSize + ")");

        Helper.printStringArray(operator.getSubject());
        System.out.println();
        return true;
    }



    public static boolean Operator_Chaining(String subject, int resize, String filter)
    {
        Operator operator = new Operator(Helper.generateStringArrayData(12));
        operator.removeDuplicates().filter(filter).Resize(resize);
        Helper.PrintSectionHeader("operator.removeDuplicates().filter(" + filter + ").Resize(" + resize + ");");

        Helper.printStringArray(operator.getSubject());
        System.out.println();
        return true;
    }


    public static void RunAllTests()
    {



        Operator_removeDuplicates();
        Operator_Filter ("One");
        Operator_Resize(8);

        Operator_Chaining("test",8,"Three");

        Validate_Email("nrnoble@hotmail.com");
        Validate_PHONE_NUMBER("253-833-1387");
        Validate_ZIP_CODE ("98002-0000");
        Validate_URL("https://egator.greenriver.edu/courses/1350941/assignments/8361180");

        Test.isEmail("nrnoble2@hotmail.com");
        Test.isPhoneNumber("253-833-1388");
        Test.isZipCode("98002-0000");
        Test.isUrl("https://egator.greenriver.edu/courses/1350941/assignments/8361180");


        Test.Before(regExTestString,"(");
        Test.After(regExTestString,"-");



        Test.RemoveDuplicatesTest();
        Test.StringArrayFilterTest("Four");
        Test.ResizeTest(8);

    }



}

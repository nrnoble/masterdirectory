/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Facade Pattern
 */

package nrnoble.Part3;
import nrnoble.Part2.Operator;

import nrnoble.Helper;
public class OperatorTest
{
    public static String[] colors = new String[] {"blue", "red", "white", "blue", "yellow", "yellow", "", "red", "red"};
    public static String[] ExpectedTestResults = new String[] {"blue", "red", "white", "blue", ""};
    public static Operator TestOperator = new Operator(colors);

    /**
     Use an operator object to reduce the following array:
     {"blue", "red", "white", "blue", "yellow", "yellow", "", "red", "red"}

     to this array
     {"blue", "red", "white", "blue", ""}

     Note: this should only take a single line of cod
     */
    public static void FindColors ()
    {
        TestOperator.Resize(7).filter("yellow");

        Helper.PrintSectionHeader("TestOperator.filter(\"yellow\").filter(\"red\");");
        System.out.println("Expected results: " + "{\"blue\", \"red\", \"white\", \"blue\", \"\"};");

    }

}

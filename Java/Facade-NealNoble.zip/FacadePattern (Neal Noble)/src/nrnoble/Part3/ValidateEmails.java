/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Facade Pattern
 */

package nrnoble.Part3;


import nrnoble.Part1.StringRegex;
import nrnoble.Helper;

public class ValidateEmails
{
    public static String[] emailAddresses = new String[] {"my_email@gmail.com","e@e.com","catch@22@.msn.com"};

    /**
     * Validate the following emails:
     my_email@gmail.com
     e@e.com
     catch@22@.msn.com
     */
    public static void ValidateEmails()
    {
        Helper.PrintSectionHeader("Validate email addresses");
        for (String item: emailAddresses)
        {
            if (StringRegex.isEmail(item))
            {
                System.out.println("  Valid: '" + item + "'");
            }
            else
            {
                System.out.println("Invalid: '" + item + "'");
            }
        }

        System.out.println();
}

}

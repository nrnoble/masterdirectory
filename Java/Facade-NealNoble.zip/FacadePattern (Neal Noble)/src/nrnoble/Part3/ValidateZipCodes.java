/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Facade Pattern
 */

package nrnoble.Part3;

import nrnoble.Part1.StringRegex;
import nrnoble.Helper;

public class ValidateZipCodes
{
    public static String[] zipCodes = new String[] {"88888-0000","98002","9999","xxxxx"};

    /**
     * Validate the following zip codes:
     99999
     88888-0000
     9999
     xxxxx
     */
    public static void ValidateZipCodes()
    {
        Helper.PrintSectionHeader("Validate Zip Codes");
        for (String item: zipCodes)
        {
            if (StringRegex.isZipCode(item))
            {
                System.out.println("  Valid: '" + item + "'");
            }
            else
            {
                System.out.println("Invalid: '" + item + "'");
            }
        }
    }
}

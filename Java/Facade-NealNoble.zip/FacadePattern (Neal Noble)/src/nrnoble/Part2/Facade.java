/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Facade Pattern
 */

package nrnoble.Part2;
import nrnoble.Part1.StringRegex;

import static nrnoble.Part2.Facade.ValidationType.ZIP_CODE;

/**
 * validate()
 This method can be used to validate any of the types from our previous class
 The ValidateType is an enum with the values: EMAIL, ZIPCODE, PHONE_NUMBER and URL
 ValidateType is used to pick the type of validation
 The validate() method then calls the appropriate method from StringRegex
 getOperator()
 The getOperator() method uses a technique called method chaining
 The getOperator() method returns an Operator object
 A class diagram of the Operator class is given below:
 */
public class Facade
{
    /**
     *  Enum of validation types
     */
    public static enum ValidationType
    {
        EMAIL,
        ZIP_CODE,
        PHONE_NUMBER,
        URL
    }

    public static enum xValidationType
    {
        x1,
        x2,
        x3,
        x4
    }


    /**
     *  Validate email, zipcode, phone, url
     * @param validationType emum of EMAIL, ZIP_CODE, PHONE_NUMBER, URL
     * @param subject string to be validated
     * @return is true if string is validated
     */
        public static boolean validate (ValidationType validationType, String subject)
        {

            switch (validationType)
            {
                case EMAIL:
                    return StringRegex.isEmail(subject);


                case PHONE_NUMBER:
                    return StringRegex.isPhoneNumber(subject);


                case ZIP_CODE:
                    return StringRegex.isZipCode(subject);


                case URL:
                    return StringRegex.isUrl(subject);


            }

            // execution should never reach this point, otherwise error in code
            return false;


        }

}

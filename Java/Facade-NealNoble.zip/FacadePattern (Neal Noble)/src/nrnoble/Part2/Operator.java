/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Facade Pattern
 */

package nrnoble.Part2;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;


import nrnoble.Part1.StringOperations;


/**
 * filter():
 This method removes all instances of search from the subject field and returns a new Operator object
 with the result of the filter operation
 Note: call the filter() method from the StringOperations class in this method
 removeDuplicates()
 This method removes all duplicates from the subject field and returns a new Operator object with the result of the remove duplicates operation
 Note: call the removeDuplicates() method from the StringOperations class in this method
 resize()
 This method resizes the subject field and returns a new Operator object with the result of the resize operation
 Note: call the resize() method from the StringOperations class in this method

 */
public class Operator
{
    private String[] subject;

    /**
     * String[] that has been processed
     * @return subject
     */
    public String[] getSubject()
    {
        return subject;
    }

    /**
     * Creates object passing in string[] to be processed
     * @param subject string[] of items.
     */
    public Operator(String[] subject)
    {
        this.subject = subject;
    }

    /**
     * filter a string[]
     * @param search string filter
     * @return filtered string[]
     */
    public Operator filter (String search)
    {
        subject =  StringOperations.filter(subject, search);
        return this;
    }

    /**
     * Remove duplicates
     * @return  string[] without duplicates
     */
    public Operator removeDuplicates()
    {
        subject = StringOperations.removeDuplicates(subject);
        return this;
    }

    /**
     * Resize the string[]
     * @param newSize the new size of array
     * @return String[] that has been resized
     */
    public Operator Resize(int newSize)
    {
        subject = StringOperations.Resize(subject,newSize);
        return this;
    }

    /**
     * return subject string[] after it has been processed
     * @return return subject string[] after it has been processed
     */
    @Override
    public String toString()
    {

        List<String> internalStrings = new ArrayList<String>(Arrays.asList(subject));
        Iterator<String>  iterator = internalStrings.iterator();

        iterator.hasNext();
        String outString = "{";
        while (iterator.hasNext())
        {
            String element = iterator.next();
            outString+= ("\"" + element);
            if (iterator.hasNext())
                outString+="\", ";
        }
        outString+= "\"}";
        return outString;

    }



}

/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Facade Pattern
 */

package nrnoble;
import nrnoble.Test;
import java.util.ArrayList;
import java.util.List;




public class Helper
{

    public static void ResetListTestData()
    {
        Test._listTestData = createListTestdata();
        printListTestData();
        System.out.println();
        System.out.println();
    }


    public static void ResetStringArrayTestData()
    {
        Test._stringArrayTestData = generateStringArrayData(12);
        PrintSectionHeader("Resetting 'StringArrayTestData' to default values");
        printStringArrayTestData();
        System.out.println();
        System.out.println();
    }


    public static String[] generateStringArrayData(int size)
    {

        String[] testData = new String[size];
        testData[0] = "Zero";
        testData[1] = "One";
        testData[2] = "Two";
        testData[3] = "Three";
        testData[4] = "Four";
        testData[5] = "Five";
        testData[6] = "Zero";
        testData[7] = "One";
        testData[8] = "Two";
        testData[9] = "Three";
        testData[10] = "Four";
        testData[11] = "Five";

        return testData;
    }


    public static List<String> createListTestdata()
    {

        List<String>  testData = new ArrayList<String>();

        testData.add ("Zero");
        testData.add ("One");
        testData.add ("Two");
        testData.add ("Three");
        testData.add ("Four");
        testData.add ("Five");
        testData.add ("Zero");
        testData.add ("One");
        testData.add ("Two");
        testData.add ("Three");
        testData.add ("Four");
        testData.add ("Five");

        return testData;
    }


    public static void printStringArrayTestData()
    {
        printStringArray(Test._stringArrayTestData);
    }


    public static void printStringArray(String[] testData)
    {
        for (int i = 0; i < testData.length; i++)
        {
            System.out.println("TestData[" + String.format("%03d",i) + "]: " + testData[i]);
        }

    }


    public static void printListTestData()
    {
        printList(Test._listTestData);
    }


    public static void printList(List<String> testData)
    {

        int i = 0;
        for (String testItem: testData)
        {
            i++;
            System.out.println("TestData[" + String.format("%03d",i) + "]: " + testItem);
        }
    }


    public static void PrintSectionHeader(String comment)
    {
        printDivider(comment.length() + 2);
        System.out.println(comment);
        printDivider(comment.length() + 2);
    }


    public static void printDivider(int length)
    {
        String divider = CreateDivider(length);
        System.out.println(divider);
    }


    public static void printDivider()
    {

        System.out.println(Test.divider);
    }


    public static String CreateDivider(int length)
    {
        String divider = "";
        for (int i = 0; i < length; i++)
        {
            divider+= "-";
        }

        return divider;

    }


    public static void assignmentHeader()
    {
        System.out.println();
        System.out.println("Neal Noble");
        System.out.println("IT426 - Facade Pattern Assignment");
        System.out.println("Instructor: Josh Archer");
        System.out.println("Oct 2016");
        System.out.println();


    }


}

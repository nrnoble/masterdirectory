/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Facade Pattern
 */

package nrnoble.Part1;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class StringRegex
{

    public static final Pattern emailPattern = Pattern.compile("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$");
    public static final Pattern phoneNumberPattern = Pattern.compile( "^(\\d{3}-?\\d{3}-?\\d{4})$");
    public static final Pattern zipCodePattern =  Pattern.compile("^\\d{5}(-\\d{4})?$");
    public static final Pattern urlPattern = Pattern.compile("^(https?:\\/\\/)?([\\da-z\\.-]+)\\.([a-z\\.]{2,6})([\\/\\w \\.-]*)*\\/?$");

    /**
     * Verifies that a email address is in valid format
     * @param subject email address to be verified
     * @return true if valid
     */
    public static boolean isEmail(String subject)
 {
     return isPatternMatch (subject,emailPattern);
 }


    /**
     * Verifies that a Zip code is in valid format
     * @param subject Zipcode to be verified
     * @return true if valid
     */
    public static boolean isZipCode(String subject)
    {
        return isPatternMatch (subject,zipCodePattern);
    }


    /**
     *  Verifies that a phone number is in valid format
     * @param subject phone to be verified
     * @return true if valid
     */
    public static boolean isPhoneNumber(String subject)
    {
        return isPatternMatch (subject,phoneNumberPattern);
    }

    /**
     *
     * @param subject Url to be verified
     * @return true if valid
     */
    public static boolean isUrl(String subject)
    {
        return isPatternMatch (subject,urlPattern);
    }

    /**
     * Verifies that string matches regular expression pattmern
     * @param subject text to be verified
     * @param regExPattern regular express that validates the subject
     * @return  true if valid
     */
    public static boolean isPatternMatch (String subject, String regExPattern)
    {
        Pattern pattern = Pattern.compile(regExPattern);
        return isPatternMatch (subject, pattern);
    }


    /**
     * Verifies that string matches regular expression pattern
     * @param subject text to be verified
     * @param pattern regular expression that validates the subject
     * @return  true if valid
     */
    public static boolean isPatternMatch (String subject, Pattern pattern)
    {
        Matcher matcher = pattern.matcher(subject);
        if (matcher.matches())
        {
            return true;
        }
        return false;
    }


}

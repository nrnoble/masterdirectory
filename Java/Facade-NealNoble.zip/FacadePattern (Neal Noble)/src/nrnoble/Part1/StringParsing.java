/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Facade Pattern
 */

package nrnoble.Part1;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;


/**
 * before():
 Returns all characters in subject from the start of the string up to the first occurrence of delimiter after():
 Returns all characters in subject from the first occurrence of delimiter to the end of the subject string
 */
public class StringParsing
{

    public static String EMPTY_STRING = "";

    /**
     * Spilts a string in two, returning the first part
     * @param subject string to be split
     * @param delimiter value that splits
     * @return returns string value upto delimiter
     */
    public static String Before (String subject, String delimiter)
    {
        //escape delimiter so that it ignores regex codes.
        String pattern = Pattern.quote(delimiter);
        String result = subject.split(pattern,2)[0];
        if (subject.equals(result))
        {
            return EMPTY_STRING;
        }

        return subject.split(pattern,2)[0];
    }

    /**
     * Spilts a string in two, returning the second part
     * @param subject string to be split
     * @param delimiter value that splits
     * @return returns string value after delimiter
     */
    public static String After (String subject, String delimiter)
    {
        //escape delimiter so that it ignores regex codes.
        String pattern = Pattern.quote(delimiter);
        String[] results = subject.split(pattern,2);

        if (results.length == 2)
        {
            return subject.split(pattern,2)[1];
        }

        return EMPTY_STRING;
    }






}

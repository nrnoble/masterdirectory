/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Facade Pattern
 */

package nrnoble.Part1;
import java.util.*;

/**
 *  removeDuplicates():
 Accepts a string array and returns a new array with all duplicates removed.
 Hint: Use a Set object to remove the duplicates.
 resize():
 Accepts a string array and an integer and creates a new array with the given size.
 Any existing elements from the input array are copied over to the new array.
 If the size of the new array is smaller than the original, then the array is truncated and any values beyond the new array size are lost.
 filter()
 Removes all instances of the given search value from the given string array
 */
public class StringOperations
{

    /**
     * Remove duplicate from a string[]
     * @param values string[]
     * @return string[] without duplicates
     */
    public static String[] removeDuplicates(String[] values)
    {
        List<String> listOfStrings  = new ArrayList<String>(Arrays.asList(values));
        listOfStrings =  removeDuplicates(listOfStrings);
        String[] returnStringArray = new String[listOfStrings.size()];
        return listOfStrings.toArray(returnStringArray);
    }


    /**
     * Remove duplicate from a List
     * @param ListOfStrings List that may have duplicates
     * @return List without duplicates
     */
    public static List<String> removeDuplicates(List<String> ListOfStrings)
    {
        Set<String> hashSet = new HashSet<>();
        hashSet.addAll(ListOfStrings);
        ListOfStrings.clear();
        ListOfStrings.addAll(hashSet);
        return ListOfStrings;
    }


    /**
     * Resizes an String[]
     * @param values String[]
     * @param newSize the size of the new array
     * @return new array that has been resized.
     */
    public static String[] Resize(String[] values, int newSize)
    {
        return  Arrays.copyOf(values, newSize);
    }

    /**
     * filter out one ore more values from a string[]
     * @param values String[]
     * @param filterString item to be filtered from String[]
     * @return Filter string[]
     * */
    public static String[] filter(String[] values, String filterString)
    {
        List<String> listOfStrings  = new ArrayList<String>(Arrays.asList(values));
        List<String> filterList = filter(listOfStrings,filterString);
        return filterList.toArray(new String[filterList.size()]);
    }

    /**
     * filter out one ore more values from a list[]
     * @param listOfStrings List
     * @param filterString item to be filtered from String[]
     * @return Filtered List
     * */
    public static List<String> filter(List<String> listOfStrings, String filterString)
    {
        listOfStrings.removeIf(filterString::equals);
        return listOfStrings;
    }
}

/*
 * Neal Noble
 * Nov 2016
 * IT426 - Josh Archer
 * Assignment - Facade Pattern
 */

import nrnoble.Helper;
import nrnoble.Part3.ValidateZipCodes;
import nrnoble.Part3.OperatorTest;
import static nrnoble.Part3.ValidateEmails.ValidateEmails;

public class Driver
{
    public static void main(String[] args)
    {

     // nrnoble.Test.RunAllTests();
        Helper.assignmentHeader();

        // Start Part 3 tests

            OperatorTest.FindColors();
            System.out.println("         results: " + OperatorTest.TestOperator.toString());
            System.out.println();
            ValidateEmails();
            ValidateZipCodes.ValidateZipCodes();

        // End Part 3 tests
    }


}

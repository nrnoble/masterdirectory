// Neal R Noble
// IT333
// April 2016
// Assignment - Assignment - List Implementation (Part one)

import java.util.*;

public class EmptyArrayList<T> implements List<T>
{
    // part #1 methods below...
    private static final int MAX_ARRAY_SIZE = Integer.MAX_VALUE - 1;
    private Object[] listOfElements;
    private static final int DEFAULT_ARRAY_SIZE = 50;
    private int elementCount;
    protected transient int modCount = 0;



    public EmptyArrayList()
    {
        this.listOfElements = new Object[DEFAULT_ARRAY_SIZE];
    }

    /**
     *  adds newElement to the uppermost index in the list. You should be able to repeatedly
     *  add listOfElements to the list (it should always resize itself to make room for new listOfElements).
     * @param newElement is the new object to be added
     * @return true if element has been added.
     */
    @Override
    public boolean add(T newElement)
    {
        //arraySizeHandler(DEFAULT_ARRAY_SIZE);

        // TODO: this solutions is very inefficient. Need to rework it so
        // that is does not call add(index,element)
        add(this.elementCount,newElement);
        //this.listOfElements[this.elementCount++] = newElement;
        return true;
    }


    /**
     * inserts newElement at the given index. All existing listOfElements should still be present
     * in the list after your insert newElement. Similar to add(), you should be able to
     * repeatedly add listOfElements to the list (it should always resize itself to make room for new listOfElements).
     * @param index of where to insert element
     * @param newElement is the new object to be inserted into array
     */
    @Override
    public void add(int index, T newElement)
    {

        if (index > this.elementCount || index < 0)
            throw new IndexOutOfBoundsException("Array elementCount: " +
                    this.elementCount + " Current index: " + index);

        arraySizeHandler(this.elementCount + 1);
        System.arraycopy(listOfElements, index, this.listOfElements, index + 1, this.elementCount - index);
        this.listOfElements[index] = newElement;
        elementCount++;
    }


    /**
     * Check of List is empty
     * @return  true if your list is empty, otherwise false.
     */
    @Override
    public boolean isEmpty()
    {
        if (this.elementCount == 0)
            return true;

        return false;
    }


    /** Size of List
     * @return the number of listOfElements in the list.
     */
    @Override
    public int size()
    {
        return this.elementCount;
    }


    /**
     *  removes all listOfElements in the list.
     */
    @Override
    public void clear()
    {
        elementCount = 0;
        this.listOfElements = new Object[DEFAULT_ARRAY_SIZE];
    }


    /**
     * returns the index of the first occurrence of search in the list.
     * If search is not found, then indexOf() should return -1.
     * @param search element
     * @return index of element. -1 if element is not found
     */
    @Override
    public int indexOf(Object search)
    {
        // do a check of null to avoid throwing an exception
        if (search == null)
        {
            for (int index = 0; index < elementCount; index++)
                if (this.listOfElements[index] == null)
                {
                    return index;
                }
        }
        else
        {
            for (int index = 0; index < elementCount; index++)
                if (search.equals(this.listOfElements[index]))
                {
                    return index;
                }
        }
        return -1;
    }


    /**
     * Check if element is in list
     * @param search element
     * @return true if element exists
     */
    @Override
    public boolean contains(Object search)
    {
        if (indexOf(search) >=0)
            return true;

        return false;
    }


    /**
     *  Get element from list
     * @param index add element at index
     * @return element that has been added
     */
     @Override
    public T get(int index)
    {
        if (boundaryCheck(index))
            return (T)this.listOfElements[index];

        return null;
    }


    /**
     *
     * @param index add element at index
     * @param value element to be added
     * @return element that has been added
     */
    @Override
    public T set(int index, T value)
    {
        if (this.boundaryCheck(index))
        {
            this.listOfElements[index] = value;
            return value;
        }
        return value;
    }


    /**
     * removes the first occurrence of search in the list. Returns true if the listOfElements
     * was found, otherwise false.
     * @param search is the element to be removed
     * @return true if element has been removed
     */
    @Override
    public boolean remove(Object search)
    {
        this.removeElement(indexOf(search));
        return true;
    }

    /**
     * remove element by index
     * @param index of element to be removed from list
     * @return null
     */
    @Override
    public T remove(int index)
    {
        this.removeElement(index);
        return null;
    }




    // part #2 methods below...

    @Override
    public boolean addAll(Collection<? extends T> other)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public boolean addAll(int index, Collection<? extends T> other)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public boolean containsAll(Collection<?> other)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public boolean removeAll(Collection<?> other)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public boolean retainAll(Collection<?> other)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public List<T> subList(int fromIndex, int toIndex)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public Object[] toArray()
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    @SuppressWarnings("hiding")
    public <T> T[] toArray(T[] toFill)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public Iterator<T> iterator()
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    // extra credit below...

    @Override
    public ListIterator<T> listIterator(int index)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public int lastIndexOf(Object search)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public ListIterator<T> listIterator()
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    private void increaseArray_size(int minArraySize)
    {

        int currentArrayLength = this.listOfElements.length;
        int increaseArraySize = currentArrayLength + (currentArrayLength >> 1);
        if (increaseArraySize - minArraySize < 0)
        {
            increaseArraySize = minArraySize;
        }

        if (increaseArraySize - this.MAX_ARRAY_SIZE > 0)
        {
            increaseArraySize = this.MAX_ARRAY_SIZE;
        }

        listOfElements = Arrays.copyOf(this.listOfElements, increaseArraySize);
    }


    private boolean boundaryCheck (int _index)
    {
        if (_index > this.elementCount || _index < 0)
            throw new IndexOutOfBoundsException("Array elementCount: " + elementCount + " Current index: " + _index);

        return true;
    }


    private void arraySizeHandler(int _min)
    {
        Object[] defaultSize = {};
        if (listOfElements == defaultSize)
        {
            _min = Math.max(this.DEFAULT_ARRAY_SIZE, _min);
        }

        listrSizeHandler(_min);
    }

    private void listrSizeHandler(int _min)
    {
        this.modCount++;

        if (_min - this.listOfElements.length > 0)
            this.increaseArray_size(_min);
    }

    private void removeElement(int index)
    {
        this.modCount++;
        int num = this.elementCount - index - 1;
        if (num > 0)
        {
            System.arraycopy(this.listOfElements,
                    index + 1,
                    this.listOfElements, index,
                    num);
        }

        this.listOfElements[--elementCount] = null;

    }


}


public class ListTester
{
    public static void main(String[] args)
    {

    }

    public static boolean testAdd(EmptyArrayList<String> myList)
    {

        boolean testpass = true;
        int failCount =  0;

        System.out.println("Add test Start");
        myList.add("A");
        if (myList.size() != 1)
            failCount++;
        if (myList.get(0) != "A")
            failCount++;

        myList.add("B");
        if (myList.size() != 2)
            failCount++;
        if (myList.get(1) != "B")
            failCount++;


        myList.add("C");
        if (myList.size() != 3)
            failCount++;
        if (myList.get(2) != "C")
            failCount++;



        // System.out.println("  Element #2: " + myList.indexOf(2));
        // System.out.println("  Size of list: " + myList.size());
        // myList.add(3);
        //System.out.println("  Element #3: " + myList.indexOf(3));
        //System.out.println("  Size of list: " + myList.size());
        if (failCount == 0)
        {
            System.out.println("All \"add\" tests have passed");
            return true;
        }
        System.out.println("Failed \"add\" tests: " + failCount );
        return false;
    }


    public static boolean testInsert(EmptyArrayList<String> myList)
    {

        boolean testpass = true;
        int failCount =  0;

        myList.add("a");

        System.out.println("Add testInsert Start");
        myList.add(1,"b");
        if (myList.size() != 1)
            failCount++;
        if (myList.get(0) != "b")
            failCount++;

        myList.add(1,"c");
        if (myList.size() != 2)
            failCount++;
        if (myList.get(1) != "c")
            failCount++;


        myList.add(2,"d");
        if (myList.size() != 3)
            failCount++;
        if (myList.get(2) != "d")
            failCount++;



        // System.out.println("  Element #2: " + myList.indexOf(2));
        // System.out.println("  Size of list: " + myList.size());
        // myList.add(3);
        //System.out.println("  Element #3: " + myList.indexOf(3));
        //System.out.println("  Size of list: " + myList.size());
        if (failCount == 0)
        {
            System.out.println("All \"testInsert\" tests have passed");
            return true;
        }
        System.out.println("Failed \"testInsert\" tests: " + failCount );

        return false;
    }

    public static boolean testIsEmpty(EmptyArrayList<String> myList)
    {
        //this method tests list.isEmpty()
        return false;
    }

    public static boolean testSize(EmptyArrayList<String> myList)
    {
        //this method tests list.size()
        return false;
    }

    public static boolean testClear(EmptyArrayList<String> myList)
    {
        //this method tests list.clear()
        return false;
    }

    public static boolean testIndexOf(EmptyArrayList<String> myList)
    {
        //this method tests list.indexOf(element)
        return false;
    }

    public static boolean testContains(EmptyArrayList<String> myList)
    {
        //this method tests list.contains(element)
        return false;
    }

    public static boolean testGet(EmptyArrayList<String> myList)
    {
        //this method tests list.get(index)
        return false;
    }

    public static boolean testSet(EmptyArrayList<String> myList)
    {
        //this method tests list.set(index, element)
        return false;
    }

    public static boolean testRemoveElement(EmptyArrayList<String> myList)
    {
        //this method tests list.remove(element)
        return false;
    }

    public static boolean testRemoveIndex(EmptyArrayList<String> myList)
    {
        //this method tests list.remove(index)
        return false;
    }
}

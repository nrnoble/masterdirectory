// Neal R Noble
// IT333
// April 2016
// Assignment - Assignment - List Implementation (Part one)

import java.util.*;

public class EmptyArrayList<T> implements List<T>
{
    // part #1 methods below...
    private static final int MAX_ARRAY_SIZE = Integer.MAX_VALUE - 1;
    private Object[]elements ;
    private static final int DEFAULT_ARRAY_SIZE = 12;
    private int size;
    protected transient int modCount = 0;



    public EmptyArrayList()
    {
        this.elements = new Object[DEFAULT_ARRAY_SIZE];
    }

    /**
     *  adds newElement to the uppermost index in the list. You should be able to repeatedly
     *  add elements to the list (it should always resize itself to make room for new elements).
     * @param newElement is the new object to be added
     * @return true if element has been added.
     */
    @Override
    public boolean add(T newElement)
    {
        elements[size++] = newElement;
        return true;
    }


    /**
     * inserts newElement at the given index. All existing elements should still be present
     * in the list after your insert newElement. Similar to add(), you should be able to
     * repeatedly add elements to the list (it should always resize itself to make room for new elements).
     * @param index of where to insert element
     * @param newElement is the new object to be inserted into array
     */
    @Override
    public void add(int index, T newElement)
    {

        if (index > size || index <= 0)
            throw new IndexOutOfBoundsException("Array size: " + size + " Current index: " + index);

        arraySizeHandler(size + 1);
        System.arraycopy(elements, index, elements, index + 1, size - index);
        elements[index] = newElement;
        size++;
    }


    /**
     * Check of List is empty
     * @return  true if your list is empty, otherwise false.
     */
    @Override
    public boolean isEmpty()
    {
        if (size == 0)
            return true;

        return false;
    }


    /** Size of List
     * @return the number of elements in the list.
     */
    @Override
    public int size()
    {
        return size;
    }


    /**
     *  removes all elements in the list.
     */
    @Override
    public void clear()
    {
        size = 0;
        elements = new Object[]{};
    }


    /**
     * returns the index of the first occurrence of search in the list.
     * If search is not found, then indexOf() should return -1.
     * @param search element
     * @return index of element. -1 if element is not found
     */
    @Override
    public int indexOf(Object search)
    {

        if (search == null)
        {
            for (int index = 0; index < size; index++)
                if (elements[index] == null)
                {
                    return index;
                }
        }
        else
        {
            for (int index = 0; index < size; index++)
                if (search.equals(elements[index]))
                {
                    return index;
                }
        }
        return -1;


    }


    /**
     * Check if element is in list
     * @param search element
     * @return true if element exists
     */
    @Override
    public boolean contains(Object search)
    {
        if (indexOf(search) >=0)
            return true;

        return false;
    }


    /**
     *  Get element from list
     * @param index add element at index
     * @return element that has been added
     */
     @Override
    public T get(int index)
    {
        if (boundaryCheck(index))
            return (T)this.elements[index];

        return null;
    }


    /**
     *
     * @param index add element at index
     * @param value element to be added
     * @return element that has been added
     */
    @Override
    public T set(int index, T value)
    {
        if (boundaryCheck(index))
        {
            elements[index] = value;
            return value;
        }
        return value;
    }


    /**
     * removes the first occurrence of search in the list. Returns true if the elements
     * was found, otherwise false.
     * @param search is the element to be removed
     * @return true if element has been removed
     */
    @Override
    public boolean remove(Object search)
    {
        removeElement(indexOf(search));
        return true;
    }


    @Override
    public T remove(int index)
    {
        removeElement(index);
        return null;
    }




    // part #2 methods below...

    @Override
    public boolean addAll(Collection<? extends T> other)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public boolean addAll(int index, Collection<? extends T> other)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public boolean containsAll(Collection<?> other)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public boolean removeAll(Collection<?> other)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public boolean retainAll(Collection<?> other)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public List<T> subList(int fromIndex, int toIndex)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public Object[] toArray()
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    @SuppressWarnings("hiding")
    public <T> T[] toArray(T[] toFill)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public Iterator<T> iterator()
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    // extra credit below...

    @Override
    public ListIterator<T> listIterator(int index)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public int lastIndexOf(Object search)
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    @Override
    public ListIterator<T> listIterator()
    {
        throw new UnsupportedOperationException("This method is not supported.");
    }

    private void increaseArray_size(int minArraySize)
    {
        // overflow-conscious code
        int currentArrayLength = this.elements.length;
        int increaseArraySize = currentArrayLength + (currentArrayLength >> 1);
        if (increaseArraySize - minArraySize < 0)
        {
            increaseArraySize = minArraySize;
        }

        if (increaseArraySize - this.MAX_ARRAY_SIZE > 0)
        {
            increaseArraySize = this.MAX_ARRAY_SIZE;
        }

        elements = Arrays.copyOf(this.elements, increaseArraySize);
    }


    private boolean boundaryCheck (int _index)
    {
        if (_index > this.size || _index < 0)
            throw new IndexOutOfBoundsException("Array size: " + size + " Current index: " + _index);

        return true;
    }


    private void arraySizeHandler(int _min)
    {
        Object[] defaultSize = {};
        if (elements == defaultSize)
        {
            _min = Math.max(this.DEFAULT_ARRAY_SIZE, _min);
        }

        listrSizeHandler(_min);
    }

    private void listrSizeHandler(int _min)
    {
        this.modCount++;

        if (_min - this.elements.length > 0)
            this.increaseArray_size(_min);
    }

    private void removeElement(int index)
    {
        this.modCount++;
        int num = this.size - index - 1;
        if (num > 0)
        {
            System.arraycopy(this.elements,
                    index + 1,
                    this.elements, index,
                    num);
        }

        this.elements[--size] = null;

    }


}
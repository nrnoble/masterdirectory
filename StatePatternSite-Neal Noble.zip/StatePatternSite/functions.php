<?php

function getpwd()
{

return "J\$p1ter2";
}